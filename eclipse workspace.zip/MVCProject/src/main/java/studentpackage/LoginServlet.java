package studentpackage;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
public class LoginServlet extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");  
	    String name=request.getParameter("name");
	    String password=request.getParameter("password");
		Login login=new Login();
		login.setName(name);
		login.setPass(password);
	request.setAttribute("loginbean",login);  
    
    boolean status=login.validate();  
      
    if(status){  
        RequestDispatcher rd=request.getRequestDispatcher("success.jsp");  
        rd.forward(request, response);  
    }  
    else{  
        RequestDispatcher rd=request.getRequestDispatcher("error.jsp");  
        rd.forward(request, response);  
    }  
  
}  

@Override  
protected void doGet(HttpServletRequest req, HttpServletResponse resp)  
        throws ServletException, IOException {  
    doPost(req, resp);  
}
}