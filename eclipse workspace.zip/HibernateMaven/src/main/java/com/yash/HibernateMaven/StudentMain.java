

import java.util.List; 
import java.util.Date;
import java.util.Iterator; 
 
import org.hibernate.HibernateException; 
import org.hibernate.Session; 
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;  

import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class StudentMain {
   private static SessionFactory factory; 
   public static void main(String[] args) {
      
      try {
    	  StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
    	  Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
          factory = meta.getSessionFactoryBuilder().build();  
      } catch (Throwable ex) { 
         System.err.println("Failed to create sessionFactory object." + ex);
         throw new ExceptionInInitializerError(ex); 
      }
      
      StudentMain ad = new StudentMain();

      /* Add few employee records in database */
      Integer stId = ad.addStudent("jaynam", "sanghvi", 20);
      Integer stId1 = ad.addStudent("jay", "sanghvi", 35);
   
      /* List down all the employees */
      ad.listEmployees();

      /* Update employee's records */
      ad.updateEmployee(stId, 5000);

      /* Delete an employee from the database */
      ad.deleteEmployee(stId1);

      /* List down new list of the employees */
      ad.listEmployees();
   }
   
   /* adthod to CREATE an employee in the database */
   public Integer addStudent(String fname, String lname, int salary){
      Session session = factory.openSession();
      Transaction tx = null;
      Integer id = null;
      
      try {
         tx = session.beginTransaction();
       Student st = new Student();
        st.setFirstName(fname);
         st.setLastName(lname);
         st.setAge(salary);
        id = (Integer) session.save(st); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      } finally {
         session.close(); 
      }
      return id;
   }
   
   /* adthod to  READ all the employees */
   public void listEmployees( ){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         List li = session.createQuery("FROM Student").list(); 
         for (Iterator iterator = li.iterator(); iterator.hasNext();){
           Student st = (Student) iterator.next(); 
            System.out.print("First Name: " + st.getFirstName()); 
            System.out.print("  Last Name: " + st.getLastName()); 
            System.out.println("  Salary: " + st.getAge()); 
         }
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      } finally {
         session.close(); 
      }
   }
   
   /* method to UPDATE salary for an employee */
   public void updateEmployee(Integer id, int age ){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         Student st = (Student)session.get(Student.class,id); 
         st.setAge( age );
		 session.update(st); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      } finally {
         session.close(); 
      }
   }
   
   /* method to DELETE an employee from the records */
   public void deleteEmployee(Integer EmployeeID){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         Student st = (Student)session.get(Student.class,id);          
         session.delete(st); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      } finally {
         session.close(); 
      }
   }
}