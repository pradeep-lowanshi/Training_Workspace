package com.yash.HibernateMaven;
import javax.persistence.*;
@Entity//marks this class as an entity
@Table(name = "Student")// if no table is mentioned it will treat a class as a table
public class Student {
	@Id @GeneratedValue
	@Column(name = "id")
	private int id;
	@Column(name = "firstName")
	   private String firstName;
	@Column(name = "lastName")
	   private String lastName;
	@Column(name = "age")
	   private int age;  
public Student() {}
	  
	   public int getId() {
	      return id;
	   }
	   
	   public void setId( int id ) {
	      this.id = id;
	   }
	   
	   public String getFirstName() {
	      return firstName;
	   }
	   
	   public void setFirstName( String first_name ) {
	      this.firstName = first_name;
	   }
	   
	   public String getLastName() {
	      return lastName;
	   }
	   
	   public void setLastName( String last_name ) {
	      this.lastName = last_name;
	   }
	   
	   public int getAge() {
	      return age;
	   }
	   
	   public void setAge( int age ) {
	      this.age = age;
	   }
}
