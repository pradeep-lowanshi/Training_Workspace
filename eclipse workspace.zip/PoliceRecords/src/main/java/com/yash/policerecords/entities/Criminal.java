package com.yash.policerecords.entities;

public class Criminal 
{
	private int criminalId;
	private String criminalName;
	private String address;
	private float height;
	private String description;
	private int charges;
	private String status;
	public void setCriminalId(int criminalId)
	{
		this.criminalId = criminalId;
	}
	public void setName(String criminalName)
	{
	    this.criminalName = criminalName;
	}
	public void setAddress(String address)
	{
		this.address = address;

	}
	public void setHeight(float height)
	{
	    this.height = height;
	}
	public void setDescription(String description)
	{
	    this.description = description;

	}
	public void setCharges(int charges)
	{
	    this.charges = charges;
	
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
	public int getCriminalId()
	{
		return criminalId;
	}
	public int getCharges()
	{
		return charges;
	}
	public String getName()
	{
		return criminalName;
	}
	public String getAddress()
	{
		return address;
	}
	public float getHeight()
	{
		return height;
	}
	public String getDescription()
	{
		return description;
	} 
	public String getStatus()
	{
		return status;
	}
}
