package officerdao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.yash.policerecords.entities.Officer;

/**
 * Servlet implementation class AddOfficerServlet
 */
@WebServlet("/AddOfficerServlet")
public class AddOfficerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddOfficerServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
//		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
//		String name = request.getParameter("offname");
//		String batchno = request.getParameter("batchno");
//		String designation = request.getParameter("designation");
//		String phone = request.getParameter("phone");
//		String password = request.getParameter("offpassword");
//		Officer of = new Officer();
//		try 
//		{
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			//creating connection
//			String url = "jdbc:mysql://localhost:3306/policerecord";
//			String user = "root"; 	
//			String pass = "root";
//			Connection con =  DriverManager.getConnection(url,user,pass);
//			of.setName(name);
//			of.setBatchNo(Integer.parseInt(batchno));
//			of.setDesignation(designation);
//			of.setContact(phone);
//			of.setPass(password);
//			String query ="INSERT INTO officer values(?,?,?,?,?)";
//			PreparedStatement ps = con.prepareStatement(query);
//			ps.setString(1,of.getName());
//			ps.setInt(2,of.getBatchNo());
//			ps.setString(3,of.getDesig());
//			ps.setString(4,of.getContact());
//			ps.setString(5,String.valueOf(of.getPass()));
//			int status = ps.executeUpdate();
//			ps.close();
//			
//		    if (status > 0)
//		    {
//		    RequestDispatcher rd=request.getRequestDispatcher("success.jsp");  
//	        rd.forward(request, response);
//		    }
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		request.getRequestDispatcher("addofficer.jsp").include(request, response);
		Cookie c[] = request.getCookies();
		if (c != null) {
			String id = c[0].getValue();
			if (!id.equals("") || id != null) {

				String name = request.getParameter("offname");
				String batchno = request.getParameter("batchno");
				String designation = request.getParameter("designation");
				String phone = request.getParameter("phone");
				String password = request.getParameter("offpassword");
				Officer of = new Officer();
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					// creating connection
					String url = "jdbc:mysql://localhost:3306/policerecord";
					String user = "root";
					String pass = "root";
					Connection con = DriverManager.getConnection(url, user, pass);
					of.setName(name);
					of.setBatchNo(Integer.parseInt(batchno));
					of.setDesignation(designation);
					of.setContact(phone);
					of.setPass(password);
					String query = "INSERT INTO officer values(?,?,?,?,?)";
					PreparedStatement ps = con.prepareStatement(query);
					ps.setString(1, of.getName());
					ps.setInt(2, of.getBatchNo());
					ps.setString(3, of.getDesig());
					ps.setString(4, of.getContact());
					ps.setString(5, String.valueOf(of.getPass()));
					int status = ps.executeUpdate();
					ps.close();

					
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		} else {
			out.print("Login first");
			request.getRequestDispatcher("adminlogin.html").include(request, response);
		}
		out.close();
	}

}
