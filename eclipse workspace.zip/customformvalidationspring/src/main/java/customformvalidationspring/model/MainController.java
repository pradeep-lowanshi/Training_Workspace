package customformvalidationspring.model;

import javax.validation.Valid;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class MainController {
                @InitBinder
                public void initBinder(WebDataBinder dataBinder) {
                                StringTrimmerEditor stringEditor = new StringTrimmerEditor(true);
                                dataBinder.registerCustomEditor(String.class,stringEditor );
                }
                @RequestMapping("/cust-regis-form")
                public String showCustomerForm(Model m) {
                                m.addAttribute("customer", new Customer()) ;
                                return "customerform" ;
                }
                @RequestMapping("/processForm")
                public String showCustomerData( @Valid @ModelAttribute("customer") Customer custom,
                                                BindingResult thebindingresult) {
                                                                if (thebindingresult.hasErrors()) {
                                                return "customerform" ;
                                }
                                else {
                                                return "customerformdata" ;
                                }
              }
  } 
