package customformvalidationspring.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import customformvalidationspring.validator.CollegeCode;

public class Customer {
	private String fname;
    @NotNull 
    @Size(min = 3, message = " This field is required ")
    private String lname;
    @Min(value = 1, message = "Tickets must be greater than or equal to 1 ")
    @Max(value = 100, message = "Tickets must be smaller than or equal to 100")
    private int tick ;
    @NotNull(message = "is Required")
    @Pattern(regexp = "^[a-zA-Z0-9]{6}", message = "must be of 6 char/digit")
    private String postal_code;
    @CollegeCode
    private String collegeCode;
    public String getCollegeCode() {
                    return collegeCode;
    }
    public void setCollegeCode(String collegeCode) {
                    this.collegeCode = collegeCode;
    }
    public String getpostal_code() {
                    return postal_code;
    }
    public void setpostal_code(String postal_code) {
                    this.postal_code = postal_code;
    }
    public int gettick() {
                    return tick;
    }
    public void settick(int tick) {
                    this.tick = tick;
    }
    public String getFname() {
                    return fname;
    }
    public void setFname(String fname) {
                    this.fname = fname;
    }
    public String getLname() {
                    return lname;
    }
    public void setLname(String lname) {
                    this.lname = lname;
    }
}
