package customformvalidationspring.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
public class Clge_CodeConstraintValidator implements ConstraintValidator<CollegeCode, String> 
{
                private String collegePrefix;
                public void initialize(CollegeCode thecc) {
                                collegePrefix = thecc.value();
                }
                public boolean isValid(String code, ConstraintValidatorContext context) {
                                boolean result; 
                                if(code != null) {
                                                result = code.startsWith(collegePrefix);
                                }
                                else
                                {
                                                result = true;
                                }
                                return result ;
                }
 }  