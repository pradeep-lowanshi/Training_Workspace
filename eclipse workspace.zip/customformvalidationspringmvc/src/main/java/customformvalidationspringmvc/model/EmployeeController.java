package customformvalidationspringmvc.model;

import javax.validation.Valid;  
import org.springframework.stereotype.Controller;  
import org.springframework.ui.Model;  
import org.springframework.validation.BindingResult;  
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.RequestMapping;  
  
@Controller  
@RequestMapping("/")
public class EmployeeController {  
      @RequestMapping("/index")
      public String index()
      {
    	  return "index";
      }
    @RequestMapping("/hello")  
    public String showForm(Model theModel) {  
          
        theModel.addAttribute("emp", new Employee());  
          
        return "viewpage";  
    }  
      
    @RequestMapping("/helloagain")  
    public String processForm(  
            @Valid @ModelAttribute("emp") Employee emp,  
            BindingResult br) { //Binding results to our pages 
                  
        if (br.hasErrors()) {  
            return "viewpage";  
        }  
        else {  
            return "final";  
        }  
    }  
}  
