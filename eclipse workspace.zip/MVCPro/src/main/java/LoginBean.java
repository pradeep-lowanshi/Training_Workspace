
public class LoginBean {

}
