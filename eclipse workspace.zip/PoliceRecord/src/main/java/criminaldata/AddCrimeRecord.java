package criminaldata;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import accounts.Criminal;

/**
 * Servlet implementation class AddCrimeRecord
 */
@WebServlet("/AddCrimeRecord")
public class AddCrimeRecord extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCrimeRecord() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int  id = Integer.parseInt(request.getParameter("cid"));
		String name = request.getParameter("cname");
		String address = request.getParameter("address");
		int height = Integer.parseInt(request.getParameter("height"));
		String desc = request.getParameter("desc");
		int charges = Integer.parseInt(request.getParameter("charge"));
		String status = request.getParameter("status");
		Criminal cr = new Criminal();
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/policerecord";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			cr.setCriminalId(id);
			cr.setName(name);
			cr.setAddress(address);
			cr.setHeight(height);
			cr.setDescription(desc);
			cr.setCharges(charges);
			cr.setStatus(status);
			String query ="INSERT INTO criminal values(?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1,cr.getCriminalId());
			ps.setString(2,cr.getName());
			ps.setString(3,cr.getAddress());
			ps.setInt(4, cr.getHeight());
			ps.setString(5, cr.getDescription());
			ps.setInt(6, cr.getCharges());
			ps.setString(7,cr.getStatus(status));
			int st = ps.executeUpdate();
			ps.close();
			
		    if (st > 0)
		    {
		    RequestDispatcher rd=request.getRequestDispatcher("offsuccess.jsp");  
	        rd.forward(request, response);
		    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
