package accounts;

public class Officer 
{
	private String name;
	private int batchNo;
	private String designation;
	private String contactNo;
	private String password;
	public void setName(String name)
	{
		this.name = name;
	}
	public void setBatchNo(int batchNo)
	{
		this.batchNo = batchNo;
	}
	public void setDesignation(String designation)
	{
		
		this.designation = designation;
	}
	public void setContact(String contactNo)
	{
		
		this.contactNo = contactNo;
	}
	public void setPass(String password)
	{
		
		this.password = password;
	}

	public String getName()
	{
		return name;

	}
	public int getBatchNo(){
		return batchNo;
	}
	public String getDesig()
	{
		return designation;
	}
	public String getContact()
	{
		return contactNo;
	}
	public String getPass()
	{
		return password;
	}
	public String toString()
	{
		return name+" "+batchNo+" "+designation+" "+contactNo+" "+password;

	}
}
