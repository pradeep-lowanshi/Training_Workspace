package accounts;

public class Admin {
	private String name,pass,id;
	  public String getName() {
		  return name;
	  }
	  public void setName(String name)
	  {
		  this.name=name;
	  }
	  public String getId()
	  {
		  return id;
	  }
	  public void setId(String id)
	  {
		  this.id = id;
	  }
	  public String getPass()
	  {
		  return pass;
	  }
	  public void setPass(String pass)
	  {
		  this.pass=pass;
	  }
	  public boolean validate()
	  {
		  if(pass.equals("12345")&& id.equals("Ad001M"))
		  {
			  return true;
		  }
		  else
		  {
			  return false;
		  }
	  }
}
