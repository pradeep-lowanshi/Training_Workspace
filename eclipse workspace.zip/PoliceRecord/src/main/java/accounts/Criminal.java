package accounts;

public class Criminal 
{
	private int criminalId;
	private String criminalName;
	private String address;
	private int height;
	private String description;
	private int charges;
	private String status;
	public void setCriminalId(int criminalId)
	{
		this.criminalId = criminalId;
	}
	public void setName(String criminalName)
	{
	    this.criminalName = criminalName;
	}
	public void setAddress(String address)
	{
		this.address = address;

	}
	public void setHeight(int height)
	{
	    this.height = height;
	}
	public void setDescription(String description)
	{
	    this.description = description;

	}
	public void setCharges(int charges)
	{
	    this.charges = charges;
	
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
	public int getCriminalId()
	{
		return criminalId;
	}
	public int getCharges()
	{
		return charges;
	}
	public String getName()
	{
		return criminalName;
	}
	public String getAddress()
	{
		return address;
	}
	public int getHeight()
	{
		return height;
	}
	@Override
	public String toString() {
		return "Criminal [criminalId=" + criminalId + ", criminalName=" + criminalName + ", address=" + address
				+ ", height=" + height + ", description=" + description + ", charges=" + charges + ", status=" + status
				+ "]";
	}
	public String getDescription()
	{
		return description;
	} 
	public String getStatus(String status)
	{
		return status;
	}
}
