package logins;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class OfficerLoginServlet
 */
@WebServlet("/OfficerLoginServlet")
public class OfficerLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OfficerLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//request.getRequestDispatcher("officeroption.jsp").include(request, response);
		HttpSession session = request.getSession();//for session
		String batch = request.getParameter("batchno");
		String password = request.getParameter("ofpassword");
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/policerecord";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			String query ="select *from officer where batchno=? and password = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1,batch);
			ps.setString(2,password);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				//out.print("<br>Welcome:" + batch);
				Cookie c = new Cookie("name",batch);
				c.setMaxAge(5);
				response.addCookie(c);
				 RequestDispatcher rd=request.getRequestDispatcher("officeroption.jsp");  
				 //RequestDispatcher rd=request.getRequestDispatcher("officeroption.jsp"+batch);//Not working  
//			        // RequestDispatcher rd=request.getRequestDispatcher("adminoptions.jsp"+id); //for session login 
			        rd.forward(request, response);  
			}
			else
			{
//				out.print("sorry password not match");
//				request.getRequestDispatcher("officerlogin.jsp").include(request, response);
				 RequestDispatcher rd=request.getRequestDispatcher("error.jsp");  
			        rd.forward(request, response);  
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
