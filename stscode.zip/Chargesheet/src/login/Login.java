package login;

import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import criminaldata.AddCriminal;
import criminaldata.DeleteRecord;
import criminaldata.UpdateCriminalStatus;
import criminaldata.ViewCriminal;
import officersdata.AddOfficer;
import officersdata.RemoveOfficer;
import officersdata.ViewOfficer;

public class Login 
{
	
	public void login()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Login-As: 1. Admin/n2. Officer");
		int choice = sc.nextInt();
		AddOfficer officer = new AddOfficer();
		ViewOfficer view = new ViewOfficer();
		Console cn = System.console();
		//char[] pas;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/chargesheet";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			
		
		
		if(choice ==1)
		{
			System.out.println("Enter the Admin Id");
			String id = sc.next();
			System.out.println("Enter the Password");
			String password = sc.next();
			String query ="select *from admin where adminId=? and adminPass = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1,id);
			ps.setString(2,password);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				System.out.println("Choose one to proceed...");
				System.out.println("1. Add Officer\n2.View Officer\n3.Remove Officer");
				int ch = sc.nextInt();
				if(ch == 1)
				{
					officer.addOfficer();	
				}
				else if(ch == 2)
				{
					//System.out.println("View Officer");
					System.out.println("1. View All Officers\n2.View Officer");
					int v = sc.nextInt();
					if(v == 1)
					{
						view.viewAllOfficer();
					}
					else
					{
						view.viewOfficerByData();
					}
					
					
				}
				else
				{
					//System.out.println("Remove Officer");
					RemoveOfficer.removeOfficer();
				}
				
			}
			else
			{
				System.out.println("Invalid Id/Password Try again");
				login();
			}
		}
		else
		 {
			System.out.println("Enter the batch number");
			int batch = sc.nextInt();
			System.out.println("Enter the password");
//			pas = cn.readPassword();
//			String password = String.valueOf(pas);
			String password = sc.next();
			PreparedStatement ps = con.prepareStatement("select * from officer where batchNo=? and password=?");
			ps.setInt(1,batch);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				//System.out.println("Hello");
				System.out.println("Welcome Officer");
				System.out.println("Choose action to perform..\n1.Add Criminal Record\n2.View Record\n3.Update Status\n4.Delete Record");
				choice = sc.nextInt();
				switch(choice)
				{
				case 1:
					AddCriminal.addCriminal();
					break;
				case 2:
					System.out.println("1.View All\n2.View Specific");
					choice = sc.nextInt();
					if(choice == 1)
					{
						ViewCriminal.viewAll();
					}
					else
					{
						ViewCriminal.viewSpecific();
					}
					break;
				case 3:
					UpdateCriminalStatus.updateStatus();
					break;
				case 4:
					DeleteRecord.deleteRecord();
					break;
//				case 5:
//					System.out.println("Change password");
//					
				}
			}
			else
			{
				System.out.println("Invalid Id/Password try again");
				login();
			}
			
			
			
			
			
		 }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
