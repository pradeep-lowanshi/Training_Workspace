//import java.sql.*;
//
//import CreateAccount.Admin;
//
//public class DatabaseConnectivity 
//{
//	
//	public String query;
//	PreparedStatement ps;
//	Admin ad = new Admin();
//
//	{
//	try
//	{
//	//load driver
//	Class.forName("com.mysql.cj.jdbc.Driver");
//	//creating connection
//	String url = "jdbc:mysql://localhost:3306/chargesheet";
//	String user = "root"; 	
//	String pass = "root";
//	Connection con =  DriverManager.getConnection(url,user,pass);
//	Statement   statement = con.createStatement();
////	String database = "CREATE DATABASE chargesheet";
////	statement.execute(database);
//	//con = DriverManager.getConnection("jdbc:mysql://localhost:3306/chargesheet","root","root");
//	
//	String adminTable = "CREATE TABLE admin(adminId varchar(10), adminName varchar(20),adminPass varchar(20))";
//	statement.execute(adminTable);
//	String officerTable = "CREATE TABLE officer(name varchar(10), batchNo int(10), desognation varchar(20), contactNo int(10),password varchar(10))";
//	statement.execute(officerTable);
//	String criminalTable = "CREATE TABLE criminal(criminalName varchar(10),address varchar(30),height int(10), description varchar(30),charges int (10))";
//	statement.execute(criminalTable);
////	String adminTable = "CREATE TABLE admin(adminId varchar(10), adminName varchar(20),adminPass varchar(20))";
////	statement.execute(adminTable);
//	
//	//creating query
//	
//	//String query ="";
//	
//	ps = con.prepareStatement(query);	
//	ps.setString(1,ad.getAdminId());
//	ps.setString(2,ad.getAdminName());
//	ps.setString(3,ad.getAdminPass());
//	ps.executeUpdate();
//	}
//	catch(Exception e)
//	{
//		e.printStackTrace();
//	}
//
//}
//}
