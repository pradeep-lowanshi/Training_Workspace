package officersdata;

import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import accounts.Officer;
import login.Login;

public class AddOfficer 
{
	
		Scanner sc = new Scanner(System.in);
		Officer of = new Officer();
		Console cn = System.console();
		Login log = new Login();
		//char[] ch;
		public void addOfficer()
		{
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				//creating connection
				String url = "jdbc:mysql://localhost:3306/chargesheet";
				String user = "root"; 	
				String pass = "root";
				Connection con =  DriverManager.getConnection(url,user,pass);
				System.out.println("Enter the name");
				of.setName(sc.next());
				System.out.println("Enter the batch number");
				of.setBatchNo(sc.nextInt());
				System.out.println("Enter te designation");
				of.setDesignation(sc.next());
				System.out.println("Enter the contact Number");
				of.setContact(sc.next());
				System.out.println("Enter the password");
//				ch = cn.readPassword();
//				String s = String.valueOf(ch);
//				of.setPass(s);
				of.setPass(sc.next());
				
				String query ="INSERT INTO officer values(?,?,?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1,of.getName());
				ps.setInt(2,of.getBatchNo());
				ps.setString(3,of.getDesig());
				ps.setString(4,of.getContact());
				ps.setString(5,String.valueOf(of.getPass()));
				ps.executeUpdate();
				ps.close();
				System.out.println("Account added");
				System.out.println("Add mor accounts?1.Yes  2. No");
				int ch = sc.nextInt();
				if(ch == 1)
				{
					addOfficer();
				}
				else
				{
					log.login();
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	
}
