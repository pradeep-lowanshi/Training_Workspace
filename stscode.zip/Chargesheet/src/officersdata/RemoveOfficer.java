package officersdata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import login.Login;

public class RemoveOfficer 
{
	
	static Scanner sc = new Scanner(System.in);
	static Login log = new Login();
	static ViewOfficer view = new ViewOfficer();
	public static void  removeOfficer()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/chargesheet";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			System.out.println("Enter Batch No");
			int batch = sc.nextInt();
			PreparedStatement ps = con.prepareStatement("delete from officer where batchNo=?");
			ps.setInt(1, batch);
			ps.executeUpdate();
			ps.close();
			
			System.out.println("Profile Removed.");
			System.out.println("Remove another 1.Yes\n2.No");
			int ch = sc.nextInt();
			if(ch==1)
			{
				removeOfficer();
			}
			else
			{
				//System.out.println("Move to Home");
				view.viewOfficerByData();
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
