//package officersdata;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.util.Scanner;
//
//public class OfficerPassword 
//{
//	static Scanner sc = new Scanner(System.in);
//	public static void changePassword()
//	{
//		try
//		{
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			//creating connection
//			String url = "jdbc:mysql://localhost:3306/chargesheet";
//			String user = "root"; 	
//			String pass = "root";
//			Connection con =  DriverManager.getConnection(url,user,pass);
//			System.out.println("Enter old password");
//			String oldPass = sc.next();
//			String query = "select * from criminal"
//			
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
//	}
//}
