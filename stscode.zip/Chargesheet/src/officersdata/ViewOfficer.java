package officersdata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import login.Login;

public class ViewOfficer 
{
	Scanner sc = new Scanner(System.in);
	static Login log = new Login();
	public void viewAllOfficer()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/chargesheet";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			PreparedStatement ps = con.prepareStatement("select * from officer");
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getString(1)+"  "+rs.getInt(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5));
				System.out.println("Logout??\n1.Yes\n2.No");
				int choice = sc.nextInt();
				if(choice==1)
				{
					log.login();
				}
				else
				{
					viewAllOfficer();
				}
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void viewOfficerByData()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/chargesheet";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			System.out.println("Enter Batch No");
			int batch = sc.nextInt();
			PreparedStatement ps = con.prepareStatement("select * from officer where batchNo=?");
			ps.setInt(1, batch);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				System.out.println(rs.getString(1)+"  "+rs.getInt(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5));
				System.out.println("View another\n1.Yes\n2.No");
				int choice = sc.nextInt();
				if(choice == 1)
				{
					viewOfficerByData();
					
				}
				else {
					viewAllOfficer();;
				}
			}
			else
			{
				System.out.println("Profile does not exists");
				
				log.login();
			}
			
			ps.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
