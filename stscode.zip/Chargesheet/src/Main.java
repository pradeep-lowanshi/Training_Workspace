import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import accounts.Admin;
import login.Login;

public class Main 
{
	public static void main(String[] args)
	{
		Admin ad = new Admin();
		ad.setAdminId("1");
		ad.setAdminName("Pradeep");
		ad.setAdminPass("12345");
//		
//		
//		
//		DatabaseConnectivity db = new DatabaseConnectivity();
//		db.query = "INSERT INTO admin((adminId,adminName,adminPass) values(?,?,?))";
//		
//		try
//		{
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			//creating connection
//			String url = "jdbc:mysql://localhost:3306/chargesheet";
//			String user = "root"; 	
//			String pass = "root";
//			Connection con =  DriverManager.getConnection(url,user,pass);
//			String query ="INSERT INTO admin  values(?,?,?)";
//			PreparedStatement ps = con.prepareStatement(query);
//			ps.setString(1,ad.getAdminId());
//			ps.setString(2,ad.getAdminName());
//			ps.setString(3,ad.getAdminPass());
//			ps.executeUpdate();
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
		Login login = new Login();
		login.login();
	}
}
