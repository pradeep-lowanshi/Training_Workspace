package criminaldata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class DeleteRecord 
{
	static Scanner sc = new Scanner(System.in);
	public static void deleteRecord()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/chargesheet";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			System.out.println("Enter Criminal Id");
			int id = sc.nextInt();
			PreparedStatement ps = con.prepareStatement("delete * from criminal where criminalId=?");
			ps.setInt(1, id);
			ps.executeQuery();
			ps.close();
			System.out.println("Delete another\n1.Yes\n2.No");
			int choice = sc.nextInt();
			if(choice == 1)
			{
				deleteRecord();
			}
			else
			{
				ViewCriminal.viewSpecific();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
