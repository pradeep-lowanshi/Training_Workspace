package criminaldata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import accounts.Criminal;

public class UpdateCriminalStatus 
{
	static Scanner sc = new Scanner(System.in);
	static Criminal cr = new Criminal();
	public static void updateStatus()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/chargesheet";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			System.out.println("Enter the criminal Id");
			int id = sc.nextInt();
			System.out.println("Select status\n1.Process 2.Found guilty\n3.Not guilty\n4.False acccused");
			int choice = sc.nextInt();
			if(choice==1)
			{
				cr.setStatus("Process");
			}
			else if(choice ==2)
			{
				cr.setStatus("Found guilty");
			}
			else if(choice == 3)
			{
				cr.setStatus("Not Guilty");
				
			}
			else
			{
				cr.setStatus("False Accused");
			}
			String update = "update criminal set status=? where criminalId=?";
			PreparedStatement ps = con.prepareStatement(update);
			ps.setString(1,cr.getStatus());
			ps.setInt(2,id);
			ps.executeUpdate();
			
			ps.close();
			System.out.println("Updated");
			System.out.println("Update another\n1.Yes\n2.No");
			choice = sc.nextInt();
			if(choice == 1) 
			{
				updateStatus();
			}
			else
			{
				ViewCriminal.viewSpecific();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
