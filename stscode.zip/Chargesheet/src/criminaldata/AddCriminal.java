package criminaldata;

import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import accounts.Criminal;
import accounts.Officer;
import login.Login;

public class AddCriminal 
{
	static Criminal cr = new Criminal();
	static Scanner sc = new Scanner(System.in);
	Console cn = System.console();
	static Login log = new Login();
	public static void addCriminal()
	{
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/chargesheet";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			System.out.println("Enter the criminal Id");
			cr.setCriminalId(sc.nextInt());
			System.out.println("Enter Name");
			cr.setName(sc.next());
			System.out.println("Enter Address");
			cr.setAddress(sc.next());
			System.out.println("Enter Height");
			cr.setHeight(sc.nextFloat());
			System.out.println("Enter description");
			cr.setDescription(sc.next());
			System.out.println("Enter Charges");
			
			cr.setCharges(sc.nextInt());
			
			System.out.println("Select status\n1.Process 2.Found guilty\n3.Not guilty\n4.False acccused");
			int choice = sc.nextInt();
			if(choice==1)
			{
				cr.setStatus("Process");
			}
			else if(choice ==2)
			{
				cr.setStatus("Found guilty");
			}
			else if(choice == 3)
			{
				cr.setStatus("Not Guilty");
				
			}
			else
			{
				cr.setStatus("False Accused");
			}
			String query = "insert into criminal values(?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1,cr.getCriminalId());
			ps.setString(2,cr.getName());
			ps.setString(3,cr.getAddress());
			ps.setFloat(4, cr.getHeight());
			ps.setString(5,cr.getDescription());
			ps.setInt(6,cr.getCharges());
			ps.setString(7,cr.getStatus());
			ps.executeUpdate();
			ps.close();
			System.out.println("Record Added");
			System.out.println("1. Add more record\n2.View Record\n3.Logout");
			choice = sc.nextInt();
			if(choice == 1)
			{
				addCriminal();
			}
			else if(choice == 2)
			{
				System.out.println("1.View all\n2.View Specific");
				choice = sc.nextInt();
				if(choice == 1)
				{
					ViewCriminal.viewAll();
				}
				else
				{
					ViewCriminal.viewSpecific();
				}
			}
			else
			{
				log.login();;
			}
			
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
