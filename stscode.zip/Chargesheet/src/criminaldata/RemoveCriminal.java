package criminaldata;

public class RemoveCriminal 
{

}
