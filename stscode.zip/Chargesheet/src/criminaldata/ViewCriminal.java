package criminaldata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import login.Login;

public class ViewCriminal {
	static Scanner sc = new Scanner(System.in);
	static Login log = new Login();
	public static void viewAll()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/chargesheet";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			PreparedStatement ps = con.prepareStatement("select * from criminal");
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{	
				System.out.println(  "Criminal Id: "+rs.getInt(1)+"\n"+"Criminal Name: "+rs.getString(2)+"\n"+"Address: "+rs.getString(3)+"\n"+"height: "+rs.getFloat(4)+"\n"+"description: "+rs.getString(5)+"\n"+"charges: "+rs.getInt(6)+"\n"+"Status: "+rs.getString(7));
				System.out.println("Logout??\n1.Yes\n2.No");
				int choice = sc.nextInt();
				if(choice == 1)
				{
					log.login();
				}
				else 
				{
					System.exit(0);
				}
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void viewSpecific()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/chargesheet";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			System.out.println("Enter Criminal Id");
			int id = sc.nextInt();
			PreparedStatement ps = con.prepareStatement("select * from criminal where criminalId=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				System.out.println(  "Criminal Id: "+rs.getInt(1)+"\n"+"Criminal Name: "+rs.getString(2)+"\n"+"Address: "+rs.getString(3)+"\n"+"height: "+rs.getFloat(4)+"\n"+"description: "+rs.getString(5)+"\n"+"charges: "+rs.getInt(6)+"\n"+"Status: "+rs.getString(7));
				System.out.println("View another \n1.Yes\n2.No");
				int choice  = sc.nextInt();
				if(choice == 1)
				{
					viewSpecific();
				}
				else {
					log.login();
				}
			}
			else
			{
				System.out.println("Record does not exists check other");
				viewSpecific();
			}
			ps.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
