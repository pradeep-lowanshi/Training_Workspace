package accounts;

public class Admin 
{
	private String adminId;
	private String adminName;
	private String adminPass;
	public void setAdminId(String adminId)
	{
		this.adminId = adminId;
	}
	public void setAdminName(String adminName)
	{
		
		this.adminName = adminName;
	}
	public void setAdminPass(String adminPass)
	{
		this.adminPass = adminPass;
	}
	public String getAdminName()
	{
		return adminName;
	}
	public String getAdminId()
	{
		return   adminId;
	}
	public String getAdminPass()
	{
		return adminPass;
		
	}
	public String toString()
	{
		
		return adminId+" "+adminName+" "+adminPass;
	}
//	void addOfficer()
//	{
//		
//	}
//	void viewOfficer()
//	{
//		
//	}
//	void removeOfficer()
//	{
//		
//	}
}
