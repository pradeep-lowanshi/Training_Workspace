package eventhandling;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		context.start();// start the event
		Message m = (Message) context.getBean("message");
		m.getMessage();
		context.stop();// stop the event
	}

}
