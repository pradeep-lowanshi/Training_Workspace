package com.yash.springorm.dao;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.yash.springorm.entities.Student;

public class StudentDao {
	private HibernateTemplate hibernatetemp;

	@Transactional
	public int insert(Student stu) {
		Integer i = (Integer) this.hibernatetemp.save(stu);
		return i;

	}
	@Transactional
	public void update(Student stu) {
	this.hibernatetemp.update(stu);
	}
	@Transactional
	public void delete(Student stu) {
	this.hibernatetemp.delete(stu);
	}

	public Student getStudentDetails(int i)
	{
	Student stu2=this.hibernatetemp.get(Student.class, i);
	return stu2;
	}
	public List<Student> getAllStudents()
	{
	List<Student> stu=this.hibernatetemp.loadAll(Student.class);
	return stu;
	}
	public HibernateTemplate getHibernatetemp() {
		return hibernatetemp;
	}

	public void setHibernatetemp(HibernateTemplate hibernatetemp) {
		this.hibernatetemp = hibernatetemp;
	}

}