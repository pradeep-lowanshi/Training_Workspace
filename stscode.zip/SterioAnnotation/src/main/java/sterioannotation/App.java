package sterioannotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("sterioannotation.xml");
		Employee e=context.getBean("ob",Employee.class);
		System.out.println(e.hashCode());
		Employee e2=context.getBean("ob",Employee.class);
		System.out.println(e2.hashCode());
		Employee e3=context.getBean("ob",Employee.class);
		System.out.println(e3.hashCode());
		}


	}


