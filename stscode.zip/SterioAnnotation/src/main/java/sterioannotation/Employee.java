package sterioannotation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
//We use this way of annotation to not use the use of bean tag in xml in case of multiple beans this way is more effective

//@Scope("prototype")//when this is used every time a new object is created .without this the application uses only single object
@Component("ob")
public class Employee {
@Value("Jaynam")
private String empName;
@Value("Indore")
private String location;
public String getEmpName() {
return empName;
}
public String getLocation() {
return location;
}
public void setEmpName(String empName) {
this.empName = empName;
}
public void setLocation(String location) {
this.location = location;
}
@Override
public String toString() {
return "Employee [empName=" + empName + ", location=" + location + "]";
}




}

