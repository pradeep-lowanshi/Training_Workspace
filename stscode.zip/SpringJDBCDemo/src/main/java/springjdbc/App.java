package springjdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	System.out.println( "Hello World!" );
    	ApplicationContext context=new ClassPathXmlApplicationContext("applicationcontext.xml");
    	JdbcTemplate temp = context.getBean("jdbctemp",JdbcTemplate.class);
    	String q="insert into employee(id,name) values(?,?)";

    	int msg= temp.update(q,107,"jay sanghvi");
    	System.out.println("record inserted" +msg);
    	 EmployeeDao dao=(EmployeeDao)context.getBean("edao");  
    	    List<Employee> list=dao.getAllEmployeesRowMapper();  
    	          
    	    for(Employee e:list)  
    	        System.out.println(e);  
    	}  
    
}
