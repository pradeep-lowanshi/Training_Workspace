package com.automobile;

import com.automobile.twowheeler.Hero;
import com.automobile.twowheeler.Honda;

//import com.automobile.twowheeler.Hero;
//import com.automobile.twowheeler.Honda;
public class Test{

    public static void main(String[] args){

        Hero h = new Hero();
        Honda hd = new Honda();
        System.out.println(h.getModelName());
        System.out.println(hd.getModelName());
    }
}