package com.automobile.twowheeler;
import com.automobile.Vehicle;
public class Honda extends Vehicle{
 public String getModelName()
    {
        return "ModelName";
    }
    public String  getRegistrationNumber()
    {
        return "Registration Number";
    }
    public String getOwnerName()
    {
        return "Owner Name";
    }
    public int getSpeed(int speed)
    {
    return speed;
    }
    public void cdPlayer(){

        //return "cdPlayer";
    }

}