package collectiondemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("collectioncontext.xml");
		CollectionDemo cd  = (CollectionDemo)context.getBean("CollectionDemo");
		System.out.println(cd.getAddressList());
		System.out.println(cd.getAddressSet());
		System.out.println(cd.getAddressMap());
		System.out.println(cd.getAddressPrope());
	}

}
