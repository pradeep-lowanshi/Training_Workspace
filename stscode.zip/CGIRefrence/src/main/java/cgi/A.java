package cgi;

public class A {
private int x ;
private B b;
@Override
public String toString() {
	return "A [x=" + x + ", b=" + b + "]";
}
public A(int x, B b) {
	super();
	this.x = x;
	this.b = b;
}

}
