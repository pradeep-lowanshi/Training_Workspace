package cgi;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.print("injecting the reference of other class");
		 ApplicationContext context=new ClassPathXmlApplicationContext("cgirefrencecontext.xml");
			A a = (A)context.getBean("refa");
			System.out.println(a);
			//System.out.println(a.getB().getY());
	}

}
