package cgi;

public class B {
private int y ;

public B(int y) {
	super();
	this.y = y;
}

@Override
public String toString() {
	return "B [y=" + y + "]";
}

}
