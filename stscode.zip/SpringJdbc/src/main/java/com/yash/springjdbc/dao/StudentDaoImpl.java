package com.yash.springjdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.yash.springjdbc.entities.Student;

public class StudentDaoImpl implements StudentDao {

	private JdbcTemplate jdbctemp;

	public int insert(Student stu) {

		String q = "insert into Student(id,name) values(?,?)";
		int msg = this.jdbctemp.update(q, stu.getId(), stu.getName());
		return msg;
	}
	
	public int updatedetails(Student stu) {
	// update details of student
	String q="update student set name=? where id=?";
	int msg=this.jdbctemp.update(q,stu.getName(),stu.getId());
	return msg;
	}

	public int deletedetails(int stuid) {
		// TODO Auto-generated method stub
		String q="delete from student where id=?";
		int msg=this.jdbctemp.update(q,stuid);

		return msg;

		}
	public Student selectDetails(int stuid) {
		// TODO Auto-generated method stub
		String q="select * from Student where id=?";
		RowMapper<Student> rowmapper=new RowMapperImpl();
		Student student=this.jdbctemp.queryForObject(q,rowmapper,stuid);

		return student;

		}

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

}