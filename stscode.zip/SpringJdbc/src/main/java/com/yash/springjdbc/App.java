package com.yash.springjdbc;

import java.util.Scanner;

/**
 * Hello world!
 *
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;



import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;



/**
* Hello world!
*
*/
public class App
{
public static void main( String[] args )
{
System.out.println( "Hello World!" );
ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/springjdbc/bean.xml");
System.out.println("Welcome");
Scanner sc = new Scanner(System.in);
System.out.println("Insert Admin id");
int id = sc.nextInt();
System.out.println("Insert password");
int pass =sc.nextInt();

if(id==1 && pass==12345)
{
	StudentDao stdao=context.getBean("StudentDao",StudentDao.class);
	Student s = new Student();
	int r;
	System.out.println("Select option \n1. Insert\n2.View\n3.Update\n4.Delete");
	int ch = sc.nextInt();
	switch(ch) {
	case 1:
		System.out.println("Insert Id");
		s.setId(sc.nextInt());
		System.out.println("Insert Name");
		s.setName(sc.next());
		r = stdao.insert(s);
		System.out.println(r + "Student added Successfully ");
		break;
	case 2:
		System.out.println("Enter id to View");
		s = stdao.selectDetails(sc.nextInt());
		System.out.println(s);
		break;
	case 3:
		System.out.println("Enter Id to update");
		s.setId(sc.nextInt());
		System.out.println("Enter updated Name");
		s.setName(sc.next());
		r = stdao.updatedetails(s);
		System.out.println(r + "Student updated Successfully ");
		break;
	case 4:
		System.out.println("Enter id to delete record");
		r = stdao.deletedetails(sc.nextInt());
		System.out.println(r + "Student deleted Successfully ");
		break;
	}
	System.out.println("Logout\n1.Yes\n2.No");
	ch = sc.nextInt();
	if(ch==1)
	{	
		System.out.println("Bye Bye!!!!");
		System.exit(0);
	}
	//Student s=new Student();
	//s.setId(108);
	//s.setName("Pradeep");
	//int r=stdao.insert(s);
	//System.out.println(r + "Student added Successfully ");
	////int r=stdao.updatedetails(s);
	//System.out.println(r + "Student updated Successfully ");
	//int r=stdao.deletedetails(108);//delete the details
	//System.out.println(r + "Student deleted Successfully ");
//	Student s=stdao.selectDetails(108);
//	System.out.println(s);

}
else
{
System.out.println("Wrong id password");	
}

}
}
