package com.yash.springjdbc.admin;

public class AdminLogin {

	
}
