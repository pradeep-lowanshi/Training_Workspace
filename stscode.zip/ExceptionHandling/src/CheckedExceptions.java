import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.lang.ClassNotFoundException;
class CheckedExceptions extends Thread
{
	public void run(){
		
		try
		{
			Thread.sleep(10000);
		System.out.println("Hello");
			
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
			
		}
	}
	public static void main(String[] args)
	{
		/*try
		{
			File f = new File("D:/javacode.txt");
			FileReader fr = new FileReader(f);
			Class c = Class.forName("pradeep");

		}
		catch(FileNotFoundException | ClassNotFoundException e)
		{
			e.printStackTrace();
		}*/
		CheckedExceptions c = new CheckedExceptions();
		c.start();
		c.interrupt();
	}
}