class UncheckedExceptions
{
	public static void main(String[] args)
	{
		
		try
		{
		String a = null;//Cant point a variable to null;
		System.out.println(a.charAt(0));
		System.out.println(100/0);//Cant divide a number by  zero
		int[] b = new int[3];
		b[4] = 3;//Cant access the index more than the size
		int c = Integer.parseInt("Hey!");//Hey is not a number
		String d = "Hey! there I am an associate of Yash Technologies.";
		char  s = d.charAt(59);
		System.out.println(s);
		}
		/*catch(NullPointerException | ArithmeticException | ArrayIndexOutOfBoundsException | NumberFormatException | StringIndexOutOfBoundsException e){
		e.printStackTrace();
		}*/
		catch(NullPointerException e){
			e.printStackTrace();
			
		}
		catch(ArithmeticException e){
			e.printStackTrace();
			
		}
		catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
			
		}
		catch(NumberFormatException e){
			e.printStackTrace();
			
		}
		catch(StringIndexOutOfBoundsException e){
			e.printStackTrace();
			
		}
		
	}
}