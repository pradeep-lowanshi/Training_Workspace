package employeedemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import employeedemo.dao.EmployeeDao;
import employeedemo.entities.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("employeedemo/bean.xml");
		EmployeeDao empl = context.getBean("EmpDao", EmployeeDao.class);
		Employee e = new Employee();
		e.setId(002);
		e.setName("Pradeep Lowanshi");
		e.setEmail("abc@gmail.com");
		e.setDob("31/05/2022");
		e.setContact(1234567890);
		e.setSalary(50000);

		int r = empl.insert(e);
		System.out.println(r + "Student added Successfully ");
		// int r=stdao.updatedetails(s);
		// System.out.println(r + "Student updated Successfully ");
//        int r=stdao.deletedetails(108);//delete the details
//        System.out.println(r + "Student deleted Successfully ");
	}
}
