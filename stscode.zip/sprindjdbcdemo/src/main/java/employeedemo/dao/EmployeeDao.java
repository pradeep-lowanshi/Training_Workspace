package employeedemo.dao;

import employeedemo.entities.Employee;

public interface EmployeeDao {
	public int insert(Employee emp);

	public int updatedetails(Employee emp);

	public int deletedetails(int empid);
	
}
