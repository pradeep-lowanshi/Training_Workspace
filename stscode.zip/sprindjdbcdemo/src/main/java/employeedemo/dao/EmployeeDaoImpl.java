package employeedemo.dao;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import employeedemo.entities.Employee;

public class EmployeeDaoImpl  implements EmployeeDao{
//	@Autowired
	private JdbcTemplate jdbctemp;

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public int insert(Employee emp) {
		// TODO Auto-generated method stub

		String q = "insert into Employee(id,empname,email,dob,contact,salary) values(?,?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getId(),emp.getName(),emp.getEmail(),emp.getDob(),emp.getContact(),emp.getSalary());
		return msg;
	}

	public int updatedetails(Employee emp) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deletedetails(int empid) {
		// TODO Auto-generated method stub
		return 0;
	}
}
