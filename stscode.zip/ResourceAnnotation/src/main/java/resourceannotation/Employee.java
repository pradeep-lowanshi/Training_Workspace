package resourceannotation;

import javax.annotation.Resource;

public class Employee {
	 private String id;
	    private String name;
	    /*The @Resource annotation in spring performs the autowiring functionality. 
	     * This annotation follows the autowire=byName semantics in the XML based configuration 
	     * i.e. it takes the name attribute for the injection. Below snippet shows how to use this annotation.*/
	    /*This annotation takes an optional name argument. In case no name attribute is specified with this annotation,
	     *  the default name is interpreted from the field-name or the setter method (i.e. the bean property name).
	     *   Always remember that if the @Resource annotation doesn�t find the bean with the name it will automatically
	     *    switch it�s autowiring technique to autowire=byType
	     *  (i.e. @Autowired annotation).*/
	 
	    @Resource(name="mycompany")
	    private Company company;

		@Override
		public String toString() {
			return "Employee [id=" + id + ", name=" + name + ", company=" + company + "]";
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Company getCompany() {
			return company;
		}

		public void setCompany(Company company) {
			this.company = company;
		}
}
