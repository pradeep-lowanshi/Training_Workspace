import javax.swing.*;  
public class SwingDemo {  
public static void main(String[] args) {  
JFrame f=new JFrame();//creating instance of JFrame  
          
JButton b=new JButton("click"); 
b.setBounds(130,100,100, 40);
JLabel l = new JLabel("Label");
          
f.add(b); 
    f.add(l);      
f.setSize(400,500);
f.setLayout(null);
f.setVisible(true);
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//f.dispose();
//System.exit(0);
}  
}  