class ExtractNumber
{
		public static void main(String[] args)
		{
			String s = "ab2jydk/4hfj587][vj";
			s= s.replaceAll("[^\\d]"," ");//replacing non number with space
			 s = s.trim();//remove space from start and end
			 s = s.replaceAll(" +"," ");
			 System.out.println(s);
			 
		}
}