import java.util.regex.*;

class SubStringRegex
{
	public static void main(String[] args)
	{
		String s = "Hey! there I am an associate of 'Yash Technology'.";
		Pattern pat = Pattern.compile("'(.*?)'");
		Matcher mat = pat.matcher(s);
		if(mat.find())
		{
			System.out.println(mat.group(1));
		}
	}
}