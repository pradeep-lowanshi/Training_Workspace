import java.util.regex.*;
class NewLineRegex
{
	public static void main(String[] args)
	{
		String s = "Pradeep\nLowanshi\n Medicaps\nUniversity\nIndore";
		Pattern pat = Pattern.compile("\\n");
		Matcher mat = pat.matcher(s);
		while(mat.find())
		{
			System.out.println(mat.group(s));
		}
	}
}