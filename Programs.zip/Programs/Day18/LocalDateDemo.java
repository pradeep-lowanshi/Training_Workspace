import java.time.*;
class LocalDateDemo
{
	 public static void main(String[] args)
	 {
		 LocalDate date = LocalDate.now();
		 System.out.println("Todays Date: "+date);
		 System.out.println("Yesterday Date: "+date.minusDays(1));
		 System.out.println("Tomorrow Date: "+date.plusDays(1));

	 }
}