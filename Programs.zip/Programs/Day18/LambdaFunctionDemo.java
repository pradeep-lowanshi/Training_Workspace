interface LambdaFunctionDemo
{
	public void show();
}
/*class BeforeLambda implements LambdaFunctionDemo
{
	public void show()
	{
		System.out.println("This is befor lambda");
	}
	public static void main(String[] args)
	{
		BeforeLambda b = new BeforeLambda();
		b.show();
	}
}*/
class AfterLambda
{
	public static void main(String[] args)
	{
		LambdaFunctionDemo l = ()->
		{
			System.out.println("This is after lambda");
		};
		l.show();
	}
}