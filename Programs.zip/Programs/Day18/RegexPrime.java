class RegexPrime
{
	public static void main(String[] args)
	{
		 int n = 30;
		 String s = new String(new char[n]);
		// boolean  p = s.matches(".?|(..+?)\\1+");
		  boolean  p = s.matches(".{0,1}|(.{2,})\\1+");//fist checks if it is (0/1), then checks if it is a proper multiple or not
		 System.out.println(!p);
	}
}