import java.util.regex.*;
class RegexDemo
{	
	public static void main(String[] args)
	{
		String number = "1239456789";
		System.out.println(number.matches("^[0-9]{10}$"));
		String mail = "abc.com";
		String mail1 = "abc@yahoo.com";
		Pattern pat = Pattern.compile("^(.+)@(.+)$");
		Matcher  mat  = pat.matcher(mail);
		Matcher mat1 = pat.matcher(mail1);
		System.out.println("mail: "+mat.matches()+"\n mail1: "+mat1.matches());
		String url = "http://www.google.com";
		Pattern patU = Pattern.compile("^(http|https)://?");
		Matcher  matU = pat.matcher(url);
		System.out.println("Url: "+!matU.matches());
	}
	
}