abstract class InnerClass{
abstract void show();
}
class OuterObject{
public static void main(String[] args){
	InnerClass in = new InnerClass(){
void show(){System.out.println("Inner class Method");}};
in.show();// Here we are not exctending the InnerClass but we are using it as a anonymous class
	
}

}