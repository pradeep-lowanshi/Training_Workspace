class Outer{
class Inner{
void show(){
System.out.println("Outer show");
}
}}
class OuterDemo{
public static void main(String[] args){
Outer o = new Outer();
Outer.Inner oi = new o.Inner();
oi.show();
}
}