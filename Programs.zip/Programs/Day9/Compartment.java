import java.util.Random;
abstract class Compartment
{
public abstract String notice ();
}
class FirstClass extends Compartment
{
public String notice ()
{
return "FirstClass";
}
}
class Ladies extends Compartment
{
public String notice ()
{
return "Ladies";
}
}
class General extends Compartment
{
public String notice ()
{
return "General";
}
}
class Luggage extends Compartment
{
public String notice ()
{
return "Luggage";
}
}

class TestCompartment
{
public static void main(String[] args)
{
Random r = new Random();
Compartment[] c = new Compartment[10] ;
for (int i = 0; i < 10; i++) {
int x = r.nextInt(4);

if (x == 0)
{
c[i] = new FirstClass();
}
else if (x == 1)
{
c[i] = new Ladies();
}
else if (x == 2)
{
c[i] = new General();
}
else if (x == 3)
{
c[i] = new Luggage();
}

System.out.println(c[i].notice());
}
}
}