import java.io.IOException;
import java.io.FileInputStream;
class CheckedThrows{
void show()throws IOException{
FileInputStream f = new FileInputStream("D:/Project.txt");
}
}
class ThrowsC{
public static void main(String[] args){
CheckedThrows c = new CheckedThrows();
try{
c.show();
}
catch(IOException e){
e.printStackTrace();
}
System.out.println("Didnot find the file");
}
}