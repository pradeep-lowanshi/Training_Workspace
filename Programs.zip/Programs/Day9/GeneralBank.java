abstract class GeneralBank{
abstract void getSavingsInterestRate();
abstract void getFixedDepositInterestRate();
}
class ICICIBank extends GeneralBank{
public void  getFixedDepositInterestRate(){
System.out.println("ICICI Fixed Deposit Rate= 8.5%");
}
public void getSavingsInterestRate(){
System.out.println("ICICI Savings Deposit Rate= 4%");
}
}
class SBIIBank extends GeneralBank{
public void  getFixedDepositInterestRate(){
System.out.println("SBI Fixed Deposit Rate= 7%");
}
public void getSavingsInterestRate(){
System.out.println("SBI Savings Deposit Rate= 4%");
}
}
class InterestRate{
public static void main(String[] args){
ICICIBank i = new ICICIBank();
SBIIBank s = new SBIIBank();
i.getFixedDepositInterestRate();
i.getSavingsInterestRate();
s.getFixedDepositInterestRate();
s.getSavingsInterestRate();
}
}