package testpackage;
public class Foundation{
int a = 5;
private int b = 10;
protected int c =3;
public int d = 6;

public void show(){
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
	System.out.println(d);
	
}
}