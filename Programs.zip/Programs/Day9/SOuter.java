class SOuter{
static void display(){
System.out.println("Hey");
}
static class InnerS{
void show(){
System.out.println("Inner Class");
}
}
}
class OIObject{
public static void main(String[] args){
SOuter.InnerS io = new SOuter.InnerS();
io.show();
io.display();
}
}