
class Throws2{
void show() throws ClassNotFoundException{
Class.forName("mypackage.pradeep.User");
}
}
class Throws2Main{
public static void main(String[] args){
Throws2 t =new Throws2();
try{
t.show();
}
catch(ClassNotFoundException e ){
e.printStackTrace();
}
System.out.println("Package or class specfied not exist");
}
}