class OuterS{
static class Sinner{
void show(){
System.out.println("Outer show");
}
}
}
class OuterInner{
	public static void main(String[] args){
OuterS.Sinner oi = new OuterS.Sinner();
oi.show();
}}