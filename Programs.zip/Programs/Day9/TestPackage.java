import testpackage.Foundation;
class TestPackage{
public static void main(String[] args){
	Foundation f = new Foundation();
	/*System.out.println(f.a);
System.out.println(f.b);
System.out.println(f.c);
System.out.println(f.d);*///Without method we cant directly access the non public members of a class

f.show();
	
}

}