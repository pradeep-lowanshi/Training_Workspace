import java.util.Scanner;
interface LibraryUser{
public void registerAccount();
public void requestBook();
}
class KidsUser implements LibraryUser{

Scanner sc = new Scanner(System.in);
int age ;
String bookType;
public void registerAccount(){
System.out.println("enter Age");
age = sc.nextInt();
sc.nextLine();
if(age>12){
System.out.println("Sorry age must be <12 to register as a kid");
}
else{
System.out.println("You have successfully register as a kid account");

}

}
public void requestBook(){
System.out.println("Enter the book category");
bookType = sc.nextLine();
if(bookType.equalsIgnoreCase("Kids")){
System.out.println("Book issued successfully please return within 10 days");
}
else{
System.out.println("Oops you are allowed to take only kids books");
}
}
}
class AdultUser implements LibraryUser{
	Scanner sc = new Scanner(System.in);
	int age;
	String bookType;
	public void registerAccount(){
		System.out.println("Enter your age");
		age = sc.nextInt();
		sc.nextLine();
		if(age<12){
			System.out.println("You must be >12 to register as an adult");
			
			
		}
		else{
			System.out.println("you have registered succussfully as an adult");
		}
		
	}
	public void requestBook(){
		System.out.println("Enter the category of book");
		bookType = sc.nextLine();
		if(bookType.equalsIgnoreCase("Fiction")){
			System.out.println("Book issued successfully return within7 days");
			
		}
		else{
			System.out.println("Oops you can only take adulst books");
		}
		
	}
	
}
class Library{
	public static void main(String[] args){
		KidsUser k = new KidsUser();
	AdultUser a= new AdultUser();
	k.registerAccount();
	k.requestBook();
	a.registerAccount();
	a.requestBook();
		
	}
	
}