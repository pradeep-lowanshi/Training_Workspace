class ThreadJoin extends Thread
{
	static Thread mt;
	public void run()
	{
		try
		{
			mt.join();
			for(int i =1;i<=3;i++)
			{
				System.out.println("Run thread" +i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static void main(String[] args)throws Exception
	{
		mt = Thread.currentThread();
		System.out.println("Main Thread");
		ThreadJoin tj = new ThreadJoin();
		tj.start();
		tj.join();
		try
		{
			for(int i =2;i<=3;i++)
			{
				System.out.println("Run thread" +i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}