class ThreadDaemonDemo extends Thread
{
	public void run()
	{
		if(Thread.currentThread().isDaemon())
		{
		System.out.println("I am in Daemon Thread");
		}
		else
		{
			
		}
	}
	public static void main(String[] args)
	{
		System.out.println("Main Thread");
		//Thread.currentThread().setDaemon(true);
		ThreadDaemonDemo td = new ThreadDaemonDemo();
		td.setDaemon(true);
		td.start();
		//td.setDaemon(true);
	}
}