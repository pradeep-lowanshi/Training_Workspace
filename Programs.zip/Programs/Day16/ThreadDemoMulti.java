class MyThread extends Thread
{	
	public void run()
	{
		System.out.println("I am in MyThread");
	}
}
class MyThread1 extends Thread
{
	public void run()
	{
		System.out.println("I am in MyThread1");
	}
}
class MyThread2 extends Thread
{
	public void run()
	{
		System.out.println("I am in MyThread2");
	}
}
class ThreadDemoMulti
{
	public static void main(String[] args)
	{
		MyThread t = new MyThread();
		t.start();
		MyThread1 t1 = new MyThread1();
		t1.start();
		MyThread2 t2 = new MyThread2();
		t2.start();
	}
}//start() is used to create a new thread and to make it runnable. this new thread begins inside the run() method.