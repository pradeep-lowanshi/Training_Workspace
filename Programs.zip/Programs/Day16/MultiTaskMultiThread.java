class MyClass1 extends Thread
{	
	public void run()
	{
		System.out.println(20*2);
	}
}
class MyClass2 extends Thread
{
	public void run()
	{
		System.out.println("I am in final year");
	}
}

class MultiTaskMultiThread
{
	public static void main(String[] args)
	{
		MyClass1 t = new MyClass1();
		t.start();
		MyClass2 t1 = new MyClass2();
		t1.start();
		
	}
}