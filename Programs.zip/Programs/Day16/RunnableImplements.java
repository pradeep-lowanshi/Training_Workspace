class RunnableImplements implements RunnableImplements
{

	public void run()
	{
	System.out.println("Hey! There I am using Yash Laptop");
	}
	public static void main(String[] args)
	{
		RunnableImplements tr = new RunnableImplements();
		Thread t = new Thread(tr);
		t.start();
	}
	
}