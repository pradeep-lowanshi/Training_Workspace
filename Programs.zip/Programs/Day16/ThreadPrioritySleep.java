class ThreadPrioritySleep extends Thread
{
	public void run()
	{
		
			try
			{
			
			System.out.println(Thread.currentThread().getName());
			Thread.sleep(1000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			//System.out.println(i);
		
	}
	public static void main(String[] args)
	{
		ThreadPrioritySleep ts = new ThreadPrioritySleep();
		ts.setName("Pradeep");
		ts.setPriority(MIN_PRIORITY);
		ts.start();
		ThreadPrioritySleep ts1 = new ThreadPrioritySleep();
		ts1.setName("Lovewanshi");
		ts1.setPriority(MAX_PRIORITY);
		ts1.start();

		ThreadPrioritySleep ts2 = new ThreadPrioritySleep();
		ts2.setName("Tarun");
		ts2.setPriority(NORM_PRIORITY);
		ts2.start();
		
	}
}