class SingleTaskMulti extends Thread
{
	public void run()
	{
		System.out.println(10/2);
	}
	public static void main(String[] args)
	{
		SingleTaskMulti t = new SingleTaskMulti();
		t.start();
		SingleTaskMulti t1 = new SingleTaskMulti();
		t1.start();
	}
}