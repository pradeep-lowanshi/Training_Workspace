class ThreadPrioDemo extends ThreadPrioDemo
{
	public void run()
	{
		System.out.println("In a run Method");
		System.out.println(Thread.currentThread().getPriority());
	}
	public static void main(String[] args)
	{
		System.out.println(Thread.currentThread().getPriority());//5
		Thread.currentThread().setPriority(MIN_PRIORITY);//10
		System.out.println(Thread.currentThread().getPriority());//1
		ThreadPrioDemo tp = new ThreadPrioDemo();
		tp.setPriority(7);//7
		tp.setPriority(20);//Exception illegalArgument
		tp.start();
	}
}