public class ThreadDemoRunnable implements Runnable
{	
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String[] args)
	{
		//ThreadDemo t = new ThreadDemo();
		ThreadDemo t1 = new ThreadDemo();
		Thread t = new Thread(new ThreadDemoRunnable());
		//Thread t = new Thread(t1);
		t.start();
	}
}//start() is used to create a new thread and to make it runnable. this new thread begins inside the run() method.
//start i used to call the run(_),when start is called a new stack is given to the thread and run()