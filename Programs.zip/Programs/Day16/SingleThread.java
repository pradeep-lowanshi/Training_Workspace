class SingleThread extends Thread
{
	public void run()
	{
		System.out.println(10/2);
	}
	public static void main(String[] args)
	{
		SingleThread t = new SingleThread();
		t.start();
	}
}