import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class FileInputOutputStreamDemo{
public static void main(String[] args)throws IOException{
FileInputStream in = new FileInputStream("D:/pradeep/FileReadWrite.txt");
FileOutputStream out = new FileOutputStream("D:/pradeep/abc.txt");
int c;
while((c=in.read())!=-1){
out.write(c);
System.out.println(c);
System.out.println((char)c);
}
in.close();
out.close();
}
}