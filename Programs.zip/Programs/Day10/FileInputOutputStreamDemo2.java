import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class FileInputOutputStreamDemo2{
public static void main(String[] args){
	FileInputStream in  = null;
	FileOutputStream out = null;
	try{
	//FileInputStream in = new FileInputStream("D:/pradeep/FileReadWrite.txt");
	//FileOutputStream out = new FileOutputStream("D:/pradeep/abc.txt");
	in = new FileInputStream("D:/pradeep/FileReadWrite.txt");
	out = new FileOutputStream("D:/pradeep/abc.txt",true);// true for appending the data in existing file
	
int c;
while((c=in.read())!=-1){
out.write(c);
System.out.println(c);
System.out.println((char)c);
	}
	}
	catch(IOException e){
		e.printStackTrace();
		
	}
finally{

	try{
	
if(in!=null){
	
	in.close();
}
if(out!=null){
	
	out.close();
}
}
catch(IOException e){
	
	e.printStackTrace();
}
}


}
}