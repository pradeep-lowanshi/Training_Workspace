import java.io.File;
class CountLine{
public static void main(String[] args){
File f= new File("D:/pradeep/abc.txt");
//FileReader fr = new FileReader(f);
//char[] ch = new ch[]
System.out.println(f.length());
}
}