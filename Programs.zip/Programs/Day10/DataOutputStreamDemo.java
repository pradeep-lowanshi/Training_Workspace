import java.io.FileOutputStream;
import java.io.DataOutputStream;
class DataOutputStreamDemo{
public static void main(String[] args)throws Exception{
FileOutputStream f = new FileOutputStream("D:/pradeep/data.txt");
DataOutputStream d = new DataOutputStream(f);
String str  = "Hello";

d.writeChars(str);
d.close();
f.close();


}
}