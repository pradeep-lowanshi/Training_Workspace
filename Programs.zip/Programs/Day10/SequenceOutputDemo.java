import java.io.FileInputStream;
import java.io.SequenceInputStream;
import java.io.FileOutputStream;
class SequenceOutputDemo{
public static void main(String[] args)throws Exception{
FileInputStream f1 = new FileInputStream("D:/pradeep/FileReadWrite.txt");
FileInputStream f2 = new FileInputStream("D:/pradeep/abc.txt");

SequenceInputStream st = new SequenceInputStream(f1,f2);
FileOutputStream f3 = new FileOutputStream("D:/combine.txt");
int i;
while((i=st.read())!=-1){
System.out.println((char)i);
f3.write(i);
}
st.close();
f2.close();
f1.close();
f3.close();
}
}