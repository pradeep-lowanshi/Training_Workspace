import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
class FileReaderWriter{
public static void main(String[] args)throws IOException{
File f = new File("D:/pradeep/FileReadWrite.txt");
f.createNewFile();//creating new file
FileWriter w = new FileWriter(f);
w.write("Welcome to yash");
w.close();
FileReader r = new FileReader(f);
char[] a = new char[20];//creating array to store the data
r.read(a);//read and store data
for(char c:a){//for printing the data
	System.out.println(c);//print one by one character
	r.close();
}
}
}