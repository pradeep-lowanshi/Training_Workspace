import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
class ByteArrayOutputDemo{
public static void main(String[] args)throws Exception{
FileOutputStream f1 = new FileOutputStream("D:/pradeep/byte1.txt");
FileOutputStream f2 = new FileOutputStream("D:/pradeep/byte2.txt");
ByteArrayOutputStream by = new ByteArrayOutputStream();
//by.write("Hey");
by.write(112);
by.writeTo(f1);
by.writeTo(f2);
by.flush();
by.close();
}
}