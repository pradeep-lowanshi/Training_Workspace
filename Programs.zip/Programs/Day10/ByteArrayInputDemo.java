import java.io.FileInputStream;
import java.io.ByteArrayInputStream;
class ByteArrayInputDemo{
public static void main(String[] args)throws Exception{
FileInputStream f1 = new FileInputStream("D:/pradeep/new.txt");

ByteArrayInputStream by = new ByteArrayInputStream(f1.getBytes());
int i;
while((i=by.read())!=-1){
System.out.println((char)i);
}
by.close();
}
}