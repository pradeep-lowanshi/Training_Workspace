import java.io.FileInputStream;
import java.io.DataInputStream;
class DataInputStreamDemo{
public static void main(String[] args)throws Exception{
FileInputStream f = new FileInputStream("D:/pradeep/new.txt");
DataInputStream d = new DataInputStream(f);
System.out.println(d.readInt());
}
}