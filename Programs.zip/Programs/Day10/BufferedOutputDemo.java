import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
class BufferedOutputDemo{
public static void main(String[] args){
try{
FileInputStream fin = new FileInputStream("D:/pradeep/FileReadWrite.txt");
BufferedInputStream  bin = new BufferedInputStream(fin);
FileOutputStream fon = new FileOutputStream("D:/pradeep/new.txt");
BufferedOutputStream  bon = new BufferedOutputStream(fon);
int i ;
while((i=bin.read())!=-1){
	bon.write(i);
System.out.println((char)i);
}
bin.close();
fin.close();
bon.close();
}
catch(Exception e){
e.printStackTrace();
}
}}