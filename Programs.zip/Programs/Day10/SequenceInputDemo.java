import java.io.FileInputStream;
import java.io.SequenceInputStream;
class SequenceInputDemo{
public static void main(String[] args)throws Exception{
FileInputStream f1 = new FileInputStream("D:/pradeep/FileReadWrite.txt");
FileInputStream f2 = new FileInputStream("D:/pradeep/abc.txt");
SequenceInputStream st = new SequenceInputStream(f1,f2);
int i;
while((i=st.read())!=-1){
System.out.println((char)i);
}
st.close();
f2.close();
f1.close();
}
}