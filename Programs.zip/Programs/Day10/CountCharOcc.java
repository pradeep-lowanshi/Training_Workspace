import java.io.FileInputStream;
import java.util.Scanner;
class CountCharOcc
{
public static void main(String args[]) throws Exception
{
FileInputStream f1 = new FileInputStream("D:/pradeep/yash.txt");

String str="";
int j;
while((j=f1.read())!=-1){

str +=(char)j;
}

f1.close();
int count = 0;
Scanner sc = new Scanner(System.in);
char s =sc.next().charAt(0);
for(int i =0;i<str.length();i++){
if(s == (str.charAt(i))){
	count++;
}	
	
}

System.out.println(count);

}
}