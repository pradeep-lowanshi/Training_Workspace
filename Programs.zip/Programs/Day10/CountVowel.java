import java.io.*;
class CountVowel
{
public static void main(String args[]) throws Exception
{
FileInputStream f1 = new FileInputStream("D:/pradeep/yash.txt");

String str="";
int m;
while((m=f1.read())!=-1){

str +=(char)m;
}

f1.close();
int a=0,e=0,i=0,u=0,o=0;
for(int j=0;j<str.length();j++)
{
char ch=str.charAt(j);
if(str.charAt(j)=='a' || str.charAt(j)=='A')
{
a++;
}
else if (str.charAt(j)=='e' ||str.charAt(j)=='E')
{
e++;
}
else if (str.charAt(j)=='i' || str.charAt(j)=='I')
{
i++;
}
else if (str.charAt(j)=='u' || str.charAt(j)=='U')
{
u++;
}
else if (str.charAt(j)=='o' || str.charAt(j)=='O')
{
o++;
}
}
int vowels = a+e+i+o+u;

System.out.println("Total vowels "+vowels);
System.out.println("a "+a);
System.out.println("e "+e);
System.out.println("i "+i);
System.out.println("o "+o);
System.out.println("u "+u);




}
}