//import java.util.*;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collections;
class HashmapSortKey
{ 
	/*static Map map=new HashMap();
	public static void sortkey()
	{
		ArrayList<Integer> a=new ArrayList<Integer>(map.keySet());
		Collections .sort(a);
		for (int x : a)
			System.out.println("Key = " +x+ ", Value = " + map.get(x));
		/*ArrayList<String> an=new ArrayList<String>(map.valueSet());
		Collections .sort(an);
		for (String x : an)
		System.out.println("Key = " +x+ ", Value = " + map.get(x));
	}*/
	public static void main(String[] args)
	{	Map map = new HashMap();
		map.put(12,"Yash");
		map.put(1,"Technologies");
		map.put(5,"Jaynam");
		Set s=map.entrySet();//convert set to traverse
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry =(Map.Entry)i.next();//value separation
			System.out.println("Key: "+entry.getKey()+" Value: "+entry.getValue());
		}
		
		ArrayList<Integer> a=new ArrayList<Integer>(map.keySet());
		Collections .sort(a);
		for (int x : a)
			System.out.println("Key = " +x+ ", Value = " + map.get(x));
		
		//sortkey();
	}
}