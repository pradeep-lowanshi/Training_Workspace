import java.util.Set;
import java.util.Properties;
import java.util.Iterator;
class HashMapProperties
{
	public static void main(String[] args)
	{
		Properties  capital = new Properties();
		Set state;
		String str;
		capital.put("MAdyaPradesh","Bhopal");
		capital.put("Goa","Panji");
		capital.put("Maharashtra","Mumbai");
		state = capital.keySet();
		Iterator i = state.iterator();
		while(i.hasNext())
		{
			str = (String)i.next();
			System.out.println("Capital of : "+str+" is"+capital.getProperty(str));
		}
	}
}