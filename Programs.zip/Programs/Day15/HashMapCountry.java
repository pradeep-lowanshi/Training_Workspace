import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
class HashMapCountry
{	HashMap<String, String> m1 = new HashMap<String, String>();
	HashMap<String, String>m2 = new HashMap<String,String>();
	//static String countryName;
	//static String capital;
	String saveCountry(String countryName, String capital)
	{
		
		m1.put(countryName,capital);
		//System.out.println(m1);
		Iterator<Map.Entry<String, String>> i = m1.entrySet().iterator();
		while(i.hasNext())
		{	Map.Entry <String, String>en = i.next();
			System.out.println("Key-Country: "+en.getKey()+"  Value-Capital: "+en.getValue());
			
		}
	  return countryName+""+capital;
	}
	String getCountry(String capital)
	{

		Iterator<Map.Entry<String, String>> i = m1.entrySet().iterator();
		while(i.hasNext())
		{	Map.Entry <String, String>en = i.next();
			//System.out.println("Key-Country: "+en.getKey()+"  Value-Capital: "+en.getValue());
			if(capital == en.getValue())
			{
				System.out.println(en.getKey());
				break;
			}
		}
		return capital;
		
	}
	String getCapital(String countryName)
	{

		Iterator<Map.Entry<String, String>> i = m1.entrySet().iterator();
		while(i.hasNext())
		{	Map.Entry <String, String>en = i.next();
			//System.out.println("Key-Country: "+en.getKey()+"  Value-Capital: "+en.getValue());
			if(countryName == en.getKey())
			{
				System.out.println(en.getValue());
				break;
			}
		}
		return countryName;
		
	}
	void swapMap()
	{
		
		Iterator<Map.Entry<String, String>> i = m1.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry<String,String> en = i.next();
			String key = en.getValue();
			String value = en.getKey();
			m2.put(key,value);
			
		}
		System.out.println(m2);
		/*Iterator<Map.Entry<String, String>> it = m2.entrySet().iterator();
		while(it.hasNext())
		{	Map.Entry<String,String> e = i.next();
			System.out.println("Key-Capital: "+e.getKey()+"  Country-Value: "+e.getValue());
			
		}*/
		for(Map.Entry m:m2.entrySet())//It returns the set containing all the keys and values
	  {
		  System.out.println("Key: "+m.getKey()+"Value: "+m.getValue());
		  
	  }
		
	}
	public static void main(String[] args)
	{
		HashMapCountry  h = new HashMapCountry();
		
		//String countryName = args[0];
		//String capital = args[1];
		h.saveCountry("India","Delhi");
		h.saveCountry("Japan","Tokyo");
		h.saveCountry("Uk","London");
		h.getCountry("London");
		h.getCapital("India");
		h.swapMap();
		
	}
}