import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
class MapDemo
{
	public static void main(String[] args)
	{
	  Map<Integer,String> map = new HashMap<Integer,String>();
	  map.put(10,"Yash");
	  map.put(11,"Technologies");
	  map.put(20,"Jaynam");
	  for(Map.Entry m:map.entrySet())//It returns the set containing all the keys and values
	  {
		  System.out.println("Key: "+m.getKey()+"Value: "+m.getValue());
		  
	  }
	 /*Map map = new HashMap();
	  map.put(10,"Yash");
	  map.put(11,"Technologies");
	  map.put(20,"Jaynam");
	  Set s = map.entrySet();//convert to set to traverse
	  Iterator i = s.iterator();
	  while(i.hasNext())
	  {
		Map.Entry entry = (Map.Entry)i.next();//value serperator
		System.out.println("Key: "+entry.getKey()+"Value: "+entry.getValue());
	  }*/

	}
}//Map.Entry(subinterface) Itnerface we will get key value seperatly