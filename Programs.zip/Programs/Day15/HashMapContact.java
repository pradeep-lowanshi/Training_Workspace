import java.util.HashMap;
import java.util.Iterator;
class HashMapContact
{
	public static void main(String[] args)
	{
		HashMap<String,String> contactList = new HashMap<String, String>();
		contactList.put("Pradeep","9630535029");
		contactList.put("Raj","9893934252");
		Iterator i = contactList.keySet().iterator();
		while(i.hasNext())
		{
			String key = (String)i.next();
			System.out.println("Key  "+contactList.get(key));
			
		}
		System.out.println(contactList.containsKey("Pradeep"));
		System.out.println(contactList.containsValue("9630535029"));
	}
}