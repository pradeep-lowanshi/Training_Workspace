import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class KeyExists
{
	public static void main(String[] args)
	{
		HashMap<Integer,String> hs = new HashMap<Integer,String>();
		hs.put(1,"Raj");
		hs.put(2,"Arsh");
		hs.put(3,"Shiv");
		hs.put(4,"Jay");
		hs.put(5,"Dee");
		int keyentered = Integer.parseInt(args[0]);
		String value = args[1];
		boolean valueExists = false;
	    boolean exist = false;
		Iterator<Map.Entry<Integer,String>> i= hs.entrySet().iterator();
		while(i.hasNext())
		{	
			Map.Entry<Integer, String> entry= i.next();
			if(keyentered == entry.getKey())
			{
			 exist = true;
			 break;
			
			}
			else
			{
				exist = false;
			}
			if(value == entry.getValue())
			{
				valueExists = true;
				
			}
			else
			{
				valueExists = false;
			}
			
			
		}
		if(exist)
		{
			System.out.println("Key Exists");
			
		}
		else
		{
			System.out.println("Key not exists");
		}
		if(valueExists)
		{
			System.out.println("value Exists");
			
		}
		else
		{
			System.out.println("value not exists");
		}
	}
}
