import java.util.Queue;
import java.util.PriorityQueue;
import java.util.LinkedList;
class QueueDemo
{
public static void main(String[] args)
{
	Queue<Integer> pq = new PriorityQueue<Integer>();
	pq.add(200);//queue is full throws exception
	pq.add(300);//Comparator Interface
	pq.add(400);//offer() it not throws an exception
	
	System.out.println(pq.peek());
	System.out.println(pq.poll());
	System.out.println(pq.peek());
	pq.remove();
	System.out.println(pq);
	Queue<Integer> li = new LinkedList<Integer>();
	li.add(1000);
	li.add(2000);
	li.add(3000);
	System.out.println(li.peek());
	System.out.println(li.poll());
	System.out.println(li.peek());
	li.remove();// if queue is empty it will throw an exception
	System.out.println(li);
}
}