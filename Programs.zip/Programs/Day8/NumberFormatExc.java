import java.util.Scanner;
class NumberFormatExc{
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
int s;int temp =-1;
try{
s = sc.nextInt();
temp = s*s;
}
catch(Exception e){
	System.out.println("Enter input is not in valid format"+e);
	
}
if(temp>=0){
	System.out.println(temp);
	
}
}
}