class MathOp{
public static void main(String[] args){
int[] ar = new int[5];
int sum = 0;
try{
for(int i =0;i<5;i++){
a[i] = Integer.ParseInt(args[i]);
sum+=a[i];
}
}catch(Exception e){
System.out.println("Number Format Exception"+e);
}
System.out.println(sum);
}
}