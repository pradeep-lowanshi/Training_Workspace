class ExceptionDemo1{

public static void main(String[] args){
System.out.println("Yash");
System.out.println("Tech");
System.out.println(100/0);
System.out.println("Bye");
}}