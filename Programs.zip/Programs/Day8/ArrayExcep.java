class ArrayExcep{
public static void main(String[] args){
int arr[] = new int[2];
int n = -1;
a[0]=2;
a[1] = 3;
Scanner sc = new Scanner(System.in);
try{
System.out.println("Enter index");
n = sc.nextInt();
}
catch{Exception e }{
System.out.prinlnt(""+e);
}
System.out.println(a[n]);
}

}