import java.io.FileInputStream;
class ExceptionChecked{
public static void main(String[] args){

//FileInputStream f = new FileInputStream("D:/xyz.txt");//File not found
try{
	String s = null;//NullPointer Exception
	System.out.println(s.length());
	System.out.println("Hello");
}catch(Exception e ){
System.out.println(e);
}
System.out.println("Bye");
}
}