
import java.io.*;
import java.sql.*;

class GetBlob 
{
	public static void main(String args[]) throws IOException
	{
	
		try
		{
			//load driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/Pradeep";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			//creating query
			
			String q = "select * from ImageUpload";
			PreparedStatement ps = con.prepareStatement(q);
			FileOutputStream image;
			ResultSet rs = ps.executeQuery();
			if (rs.next()) 
			{
				Blob test=rs.getBlob("image");
				InputStream x=test.getBinaryStream();
				int size=x.available();
				OutputStream out=new FileOutputStream(test);
				byte b[]= new byte[size];
				x.read(b);
				out.write(b);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception :"+e);
		}
		finally
		{
			try
			{
				x.close();
				image.close();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	
	
		
	}
}