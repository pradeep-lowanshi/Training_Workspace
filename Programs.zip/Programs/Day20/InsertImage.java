import java.sql.*;
import java.io.*;
class InsertImage
{
	public static void main(String[] args)
	{
		try
		{
			//load driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/Pradeep";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			//creating query
			
			String q = "insert into ImageUpload(image) values(?)";
			PreparedStatement ps = con.prepareStatement(q);
			//ps.setBinaryStream(1,"Image");
			InputStream in = new FileInputStream("D:/pradeep/1.png");
			//setting the values
			//ps.setInt(1,id);
			//ps.setString(2,name);
			//ps.setBinaryStream(1,"image");
			ps.setBlob(1,in);
			ps.executeUpdate();
			System.out.println("Success");
			con.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}