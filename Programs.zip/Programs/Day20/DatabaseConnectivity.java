import java.sql.*;

public class DatabaseConnectivity 
{
	public static void main(String[] args)
	{
	try
	{
	//load driver
	Class.forName("com.mysql.jdbc.Driver");
	//creating connection
	String url = "jdbc:mysql://localhost:3306/";
	String user = "root"; 	
	String pass = "root";
	Connection con =  DriverManager.getConnection(url,user,pass);
	Statement   statement = con.createStatement();
	String database = "CREATE DATABASE chargesheet";
	//String adminTable = "CREATE"
	statement.execute(database);
	//creating query
	
//	String query ="";
//	
//	PreparedStatement ps = con.prepareStatement(query);	
//	
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}

}
}
