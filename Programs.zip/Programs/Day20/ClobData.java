import java.sql.*;
import java.io.*;
class ClobData
{
	 public static void main(String[] args)
	 {
		try
		{
			//load driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/Pradeep";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			//creating query
			
			String q = "insert into clobdata(clob) values(?)";
			PreparedStatement ps = con.prepareStatement(q);
			FileReader rd = new FileReader("D:/pradeep/byte1.txt");
			ps.setClob(1,rd);
			ps.executeUpdate();
			PreparedStatement pr = con.prepareStatement("select *from clobdata");
			ResultSet rs = pr.executeQuery();
			while(rs.next())
			{
				Clob cb = rs.getClob("clob");
				System.out.println(cb);
				Reader r = cb.getCharacterStream();
				//while()
					System.out.println(r);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	 }
}