import java.sql.*;
public class JDBC1
{
public static void main(String args[])
{
try
{
//load the dirver
Class.forName("com.mysql.jdbc.Driver");
//create connection
String url="jdbc:mysql://localhost:3306/databasename";
String user ="root";
String pass ="root";
Connection con = DriverManager.getConnection(url,user,pass);
if(con!=null)
{
System.out.println("Con is success ");
}
else
{
System.out.println("Con is not create ");

}

//step 3: create query
String q ="select * from employee";
//String q2="UPDATE employee SET name='paliwal ' where id=empID=1 ";

Statement st = con.createStatement();
ResultSet set = st.executeQuery(q);
/* PreparedStatement stmt=con.prepareStatement("insert into employee values(?,?)");
stmt.setInt(1,2);//1 specifies the first parameter in the query
stmt.setString(2,"shubham"); */

while(set.next())
{
int id= set.getInt("empID");//(1)
String name= set.getString("name");//2
System.out.println("id "+id);
System.out.println("name "+name);



}
PreparedStatement ps=con.prepareStatement("select * from employee");
ResultSet rs=ps.executeQuery();
ResultSetMetaData rsmd=rs.getMetaData();

System.out.println("Total columns: "+rsmd.getColumnCount());
System.out.println("Column Name of 1st column: "+rsmd.getColumnName(1));
System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(1));



con.close();

}
catch(Exception e)
{
e.printStackTrace();
}
}
}

