import java.io.*;
import java.sql.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

 
public class GetImage 
{
	public static void main(String args[])
	{
		try
		{
			//load driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating connection
			String url = "jdbc:mysql://localhost:3306/Pradeep";
			String user = "root"; 	
			String pass = "root";
			Connection con =  DriverManager.getConnection(url,user,pass);
			//creating query
			
			String q = "select * from ImageUpload";
			PreparedStatement ps = con.prepareStatement(q);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				Blob aBlob = rs.getBlob("image");//get the value of any columne as a blob object
				InputStream is = aBlob.getBinaryStream(1, aBlob.length());//gets the value as a stream
				BufferedImage imag=ImageIO.read(is);//BufferedImage subclass describes an Image with an accessible buffer of image data. 
				//ImageIoclass used to read/write image
				//Image image = imag;
				ImageIcon icon =new ImageIcon(imag);
				JFrame jFrame = new JFrame();
				jFrame.setLayout(new FlowLayout());
				jFrame.setSize(700, 500);

				JLabel jLabel = new JLabel();
				jLabel.setIcon(icon);

				jFrame.add(jLabel);
				jFrame.setVisible(true);

				jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}
}