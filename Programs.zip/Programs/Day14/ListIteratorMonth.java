import java.util.ArrayList;
import java.util.ListIterator;

class ListIteratorMonth
{
	public static void main(String[] args)
	{
		ArrayList<String> mo = new ArrayList<String>();
		mo.add("January");
		mo.add("Febrary");
		mo.add("March");
		mo.add("April");
		mo.add("May");
		mo.add("June");
		mo.add("July");
		mo.add("August");
		mo.add("September");
		mo.add("October");
		mo.add("November");
		mo.add("December");
		System.out.println(mo);
		ListIterator li = mo.listIterator();
		li.next();
		li.next();
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
		}
	}
}