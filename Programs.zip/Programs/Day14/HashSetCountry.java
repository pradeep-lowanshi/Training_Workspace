import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
class HashSetCountry
{
 String CountryName;
 HashSet<String> h1 = new HashSet<String>();
 Iterator i = h1.iterator();
 void saveCountry(String CountryName)
 {
	h1.add(CountryName);
 }
 String getCountry()
 {
	while(i.hasNext())
	{
		return i.next();
	}
 }
 public static void main(String[] args)
 {
	HashSetCountry hs = new HashSetCountry();
	hs.saveCountry("India");
	System.out.println(hs.getCountry());
 }
}