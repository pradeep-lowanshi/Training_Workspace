import java.util.Scanner;
import java.util.Vector;
import java.util.Iterator;
import java.util.Enumeration;
class Employee
{
	String name;
	int eId;
	int contact;
	Employee(String name,int eId,int contact)
	{
		this.name=name;
		this.eId = eId;
		this.contact = contact;
	}
	public String toString()
	{
	return name+" "+eId+" "+contact;
	}
}
class VectorEmployee
{
	public static void main(String[] args)
	{
		Vector<Employee> ev = new Vector<Employee>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Eneter employee name");
		String name = sc.next();
		System.out.println("Enter employee id");
		int eId = sc.nextInt();
		System.out.println("Enter contact number");
		int contact = sc.nextInt();
		ev.add(new Employee(name,eId,contact));
		Iterator i = ev.iterator();
		while(i.hasNext())
		{
			System.out.println("with Iterator: "+i.next());
		}
		Enumeration e = ev.elements();
		while(e.hasMoreElements())
		{
			System.out.println("With Enumeration: "+e.nextElement());
		}
	}
}