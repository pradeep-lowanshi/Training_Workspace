import java.util.Vector;
import java.util.Iterator;
class VectorDemo
{
	public static void main(String[] args)
	{
		Vector<String> v = new Vector<String>();
		v.add("January");
		v.add("Febrary");
		v.add("March");
		v.add("April");
		v.add("May");
		v.add("June");
		v.add("July");
		v.add("August");
		v.add("September");
		v.add("October");
		v.add("November");
		v.add("December");
		System.out.println(v);
		for(String vl : v)
		{
			System.out.println(vl);
		}
		Iterator i = v.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
			
		}
		v.remove(3);
		System.out.println("List after remove index value: "+v);
	}
}