import java.util.TreeSet;
import java.util.NavigableSet;
import java.util.Iterator;
class TreeSetObject
{
	public static void main(String[] args)throws Exception
	{
		TreeSet<String> ts = new TreeSet<String>();
		ts.add("Tarun Nagar");
		ts.add("Ritvik Dubey");
		ts.add("Tarun Nagar");
		ts.add("Vipul Mishra");
		ts.add("Deepak Patel");
		System.out.println(ts);
		Iterator i = ts.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}//NavigableSet is a sorted Set
		NavigableSet<String> ns = ts.descendingSet();//returns a NavigableSet in which the order of the elements is reversed 
		System.out.println(ns);
	}
}