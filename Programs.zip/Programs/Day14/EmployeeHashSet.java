import java.util.HashSet;
import java.util.Iterator;
class EmployeeHashSet
{
	public static void main(String[] args)
	{
		HashSet<String> hs = new HashSet<String>();
		hs.add("Tarun Nagar");
		hs.add("Ritvik Dubey");
		hs.add("Tarun Nagar");
		hs.add("Vipul Mishra");
		hs.add("Deepak Patel");
		System.out.println(hs);
		Iterator i = hs.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}