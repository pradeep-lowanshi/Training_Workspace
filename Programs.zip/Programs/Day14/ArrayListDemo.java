import java.util.ArrayList;
class ArrayListDemo
{
	public static void main(String[] args)
	{
		//List < > o = new ArrayList<>();
		ArrayList<String> a = new ArrayList<>();
		a.add("Raj");
		a.add(20);
		a.add("Arsh");
		for(int i = 0;i<a.size();i++)
		{
		 System.out.println(a.get(i));
		}
		
	}
	
}//javac A.java - Xlint:unchecked (to remove unchecked error)