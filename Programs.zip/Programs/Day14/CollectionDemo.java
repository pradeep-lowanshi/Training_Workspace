import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
public class CollectionDemo
{
 public static void main(String[] args)
 {
 ArrayList a = new ArrayList();
 a.add(10);
 a.add("YAsh");
 a.add('j');
 HashSet h = new HashSet();
 h.add("technologies");
 h.add(20);
 HashMap hm = new HashMap();
 hm.put(1000, "Jay");
 hm.put(1001,"Yas");
 }
}