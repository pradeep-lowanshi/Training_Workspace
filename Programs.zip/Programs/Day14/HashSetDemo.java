import java.util.HashSet;
import java.util.Iterator;
class HashSetDemo
{
	public static void main(String[] args)
	{
		HashSet<String> hs = new HashSet<String>();
		hs.add("Raj");
		hs.add("Raj");
		hs.add("A");
		hs.add("B");
		System.out.println(hs);
		Iterator i = hs.iterator();
		while(i.hasNext()){
			
			System.out.println(i.next());
		}
		for(String h : hs)
		{
			System.out.println(h);
		}
	}
}