import java.util.LinkedList;
class LinkedListDemo
{
	public static void main(String[] args)
	{
		LinkedList<String> ls = new LinkedList<String>();
		ls.add("Raj");
		ls.add("Raj");
		ls.add("A");
		ls.add("B");
		System.out.println(ls);
		for(String l : ls)
		{
			System.out.println(l);
			
		}ls.remove(2);
		System.out.println(ls);
	}
}