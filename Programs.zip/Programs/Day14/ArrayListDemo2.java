import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collections;
public class ArrayListDemo2
{
	public static void main(String[] args)
	{
		ArrayList<String> al = new ArrayList<String>();
		al.add("A");
		al.add("B");
		al.add("c");
		al.add("D");// cursors 1)Iterator 2)ListIterator 3)Enumeration
		Iterator i = al.iterator();
		while(i.hasNext())//check if iterator has elements
		{
			System.out.println(i.next());//print current and move to next
		}
		for(String j : al)
		{
			System.out.println("FOR EACH"+ j);
		}
		System.out.println("Get element index 1"+ al.get(1));//get the value at index
		al.set(2, "Yash");//Setting the value at index
		for(String j : al)
		{
			System.out.println(j);
		}
		Collections.sort(al);
		for(String j:al)
		{
			System.out.println(j);
		}
	}
}