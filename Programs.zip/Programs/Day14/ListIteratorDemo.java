import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
public class ListIteratorDemo
{
	public static void main(String[] args)
	{
		ArrayList<String> al = new ArrayList<String>();
		al.add("A");
		al.add("B");
		al.add("c");
		al.add("D");
		
		ListIterator li = al.listIterator();
		li.next();
		li.next();
		while(li.hasPrevious())//check if there is any previous element
		{
			System.out.println(li.previous());//print previous
		}
		//li.add("Yash");
		//System.out.println(al);
		li.set("Technologies");//update 0 index
		System.out.println(al);
	}
}