import java.util.ArrayList;
import java.util.Iterator;

class ArrayListMonth
{
	public static void main(String[] args)
	{
		ArrayList<String> mo = new ArrayList<String>();
		mo.add("January");
		mo.add("Febrary");
		mo.add("March");
		mo.add("April");
		mo.add("May");
		mo.add("June");
		mo.add("July");
		mo.add("August");
		mo.add("September");
		mo.add("October");
		mo.add("November");
		mo.add("December");
		System.out.println(mo);
		for(int i =0;i<mo.size();i++)
		{
			System.out.println(mo.get(i));
		}
		for(String a : mo)
		{
			System.out.println("For Each: "+a);
		}
		Iterator i = mo.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}