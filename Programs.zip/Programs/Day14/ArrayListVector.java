import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

class ArrayListVector
{
	public static void main(String[] args)
	{
		ArrayList<String> mo = new ArrayList<String>();
		mo.add("January");
		mo.add("Febrary");
		mo.add("March");
		mo.add("April");
		mo.add("May");
		mo.add("June");
		mo.add("July");
		mo.add("August");
		mo.add("September");
		mo.add("October");
		mo.add("November");
		mo.add("December");
		System.out.println(mo);
		Vector<String> v = new Vector<String>();
		for(String l : mo)
		{
			v.add(l);
		}
		Iterator i = v.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}