class ArrayTest
{
	static int a = 3;
	public String s = "Hey There";
	void show()
	{
		System.out.println(s);
		
	}
	public static void main(String[] args)throws Exception
	{
		int arr[] = new int[2];
		arr[0] =1;
		arr[1] = 2;
		int  b = 5;
		Class d = int.class;
		Class c = Class.forName("ArrayTest");
		System.out.println(arr.getClass().isArray());
		System.out.println(d.isPrimitive());
	}
}