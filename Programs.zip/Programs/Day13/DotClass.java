class DotClass
{
	public static void main(String[] args)
	{
		Class c = String.class;
		System.out.println(c.getName());
	}
}