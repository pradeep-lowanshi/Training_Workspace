class GetClass{}
class GetClassName
{
	void show(Object obj)
	{
		Class c = obj.getClass();
		System.out.println(c.getName());
	}
	public static void main(String[] args)
	{
		GetClass g = new GetClass();
		Class c = g.getClass();
		GetClassName d = new GetClassName();
		d.show(g);
	}

}