class Fabonacci{
public static void main(String [] args)
{
  int a =Integer.parseInt(args[0]);
int sum = 0;
for(int i =1;i<=a;i++){
sum +=i;
}
System.out.println(sum);
}
}