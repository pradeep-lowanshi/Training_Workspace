class Palindrome{
public static void main(String [] args)
{
int a = Integer.parseInt(args[0]);
int ori = a;
int reverse = 0;
while(a!=0)
{
int b = a%10;
reverse = reverse*10+b;
a/=10;
}
if(ori==reverse)
{
System.out.println("Palindrome");
}
else{
System.out.println("Not Palindrome");
}
}
}