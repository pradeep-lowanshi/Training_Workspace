class PrimeCheckSum{
public static void main(String [] args){
int a =Integer.parseInt(args[0]);
int sum =0;
for(int i = 2;i<=a;i++){
if(a%i=0){
System.out.println(i);

}
sum +=i;

}
System.out.println(sum);
}
}