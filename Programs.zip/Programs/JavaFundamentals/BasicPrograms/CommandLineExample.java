class CommandLineExample{
public static void main(String [] args){
System.out.println("command line ="+args[0]);
}
}