class Animal{
void eat(){
System.out.println("I am eating");
}
public static void main(String[] args){
System.out.println("Hello");
Animal sheru = new Animal();
sheru.eat();
}
}