class Animal1{
String color;
int age;
public static void main(String[] args){
Animal1 sheru = new Animal1();
sheru.color = "black";//by reference variable 
sheru.age = 15;
System.out.println(sheru.color+" "+sheru.age);
}
}