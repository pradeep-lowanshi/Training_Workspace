class ReverseNumber{
public static void main(String [] args)
{
int a = Integer.parseInt(args[0]);
int reverse = 0;
while(a!=0){
int b = a%10;
reverse = reverse*10+b;
a/=10;
}
System.out.println(reverse);
}
}