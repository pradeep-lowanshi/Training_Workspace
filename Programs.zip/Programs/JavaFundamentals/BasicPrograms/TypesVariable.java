class TypesVariable{
int a = 20;//instance
static int b = 30;//static
void add(){
int c;//local
c= a+b;
System.out.println(c);
}
public static void main(String [] args){
TypesVariable ob1 = new TypesVariable();
System.out.println(ob1.a);
System.out.println(ob1.b);
ob1.a= 50;
ob1.b=450;
Sytem.out.println(ob1.a);//50
System.out.println(ob1.b);//450
TypesVariable ob2 = new TypesVariable();
System.out.println(ob2.a);//20
System.out.println(ob2.b);//450
}
}