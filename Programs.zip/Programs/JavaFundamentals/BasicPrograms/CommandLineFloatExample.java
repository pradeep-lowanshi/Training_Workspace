class CommandLineFloatExample{
public static void main(String [] args){
float a = Float.parseFloat(args[0]);
System.out.println("a="+a);
}
}