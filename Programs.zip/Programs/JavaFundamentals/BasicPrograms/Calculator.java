class Calculator{
public static void main(String [] args)
{
 int a = Integer.parseInt(args[0]);
int b  = Integer.parseInt(args[1]);
String ch = args[2];

switch(ch){
case "+":
   System.out.println(a+b);
   break;
case "-":
   System.out.println(a-b);
   break;
case "*":
   System.out.println(a*b);
   break;
case "/":
   System.out.println(a/b);
   break;
}
}
}