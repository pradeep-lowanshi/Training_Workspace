class FactorialRecursion{
static int fact(int n ){

if(n==0){
return 1;
}
else{
return(n*fact(n-1));
}}

public static void main(String [] args)
{
int facto = 1;

int n = Integer.parseInt(args[0]);
System.out.println("factorial"+fact(n));



}
}