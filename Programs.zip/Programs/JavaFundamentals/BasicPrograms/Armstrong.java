class Armstrong{
public static void main(String [] args)
{
int a = Integer.parseInt(args[0]);
int ori = a;
int sum = 0;
while(a!=0)
{
int b = a%10;
sum= sum+b*b*b;
a/=10;
}
if(sum==ori)
{
System.out.println("Armstrong");
}
else{
System.out.println("Not Armstrong");
}
}
}