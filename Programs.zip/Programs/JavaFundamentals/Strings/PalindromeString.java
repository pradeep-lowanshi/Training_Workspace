class PalindromeString{
public static void main(String[] args){
  String s = args[0];
  int n = s.length();
  String s1 = "";
  
  for(int i = n-1;i>=0;i--){
  s1 = s1+s.charAt(i);
  
  }
  if(s.equals(s1)){
	  System.out.println("Palindrome");
  }
  else{
	  System.out.println("Not Palindrome");
  }
}
}