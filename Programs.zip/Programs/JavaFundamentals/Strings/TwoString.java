class TwoString{
public static void main(String[] args){
String s = "Yash";
String s2 = "Technology";
StringBuilder sb = new StringBuilder();

for(int i = 0;i<s.length()||i<s2.length();i++){
if(i<s.length()){//checking the length of the first string if it exists.
	sb.append(s.charAt(i));
}
if(i<s2.length()){//checkingthe length of the second string if it exists.
	
	sb.append(s2.charAt(i));
}
}
System.out.println(sb);
}
}
/*class TwoString{
	public static void main(String [] args){
		String s = "Yash";
		String s2 = "Technologies";
		char[] ch1 = s.toCharArray();
		char[] ch2 = s.toCharArray();
		
		StringBuilder sb = new StringBuilder();
		for(int i = 0;i<ch1.length||i<ch2.length;i++){
			if(i<ch1.length){
				sb.append(ch1[i]);
			}
			if(i<ch2.length){
				sb.append(ch2[i]);
				
			}
		}
		System.out.println(sb);
	}
}*/