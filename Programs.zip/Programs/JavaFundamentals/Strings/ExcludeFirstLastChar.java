class ExcludeFirstLastChar{
public static void main(String[] args){
String s = args[0];
int l = s.length();
if(l>2){
for(int i = 1;i<l-1;i++){
System.out.print(s.charAt(i));
}

}
else{
System.out.println("Please string with length more than 2");
}
}
}