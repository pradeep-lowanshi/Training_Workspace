class StringBuilderExample{
public static void main(String[] args){
StringBuilder sb = new StringBuilder("Welcome associate to the new world of technology");
System.out.println(sb.indexOf("a"));
System.out.println(sb.lastIndexOf("w"));
System.out.println(sb.replace(8,17,"onboard"));
System.out.println(sb.subSequence(10,15));
}
}