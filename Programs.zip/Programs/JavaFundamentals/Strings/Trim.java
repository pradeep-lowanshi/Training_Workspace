class Trim{
public static void main(String[] args){
String sb = new String("   Yash   ");
System.out.println(sb.trim());
}
}
//It removes white spaces before and after the string