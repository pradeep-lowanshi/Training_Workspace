class CompareToIgnoreCase{
public static void main(String[] args){
String s1 = "Yash";
String s2 = "yash";
System.out.println(s1.compareTo(s2));
System.out.println(s1.compareToIgnoreCase(s2));
}
}