class SubString{
public static void main(String[] args){
String s = "Hey there! I am an associate in Yash Technologies";
System.out.println(s.substring(6,10));
}
}