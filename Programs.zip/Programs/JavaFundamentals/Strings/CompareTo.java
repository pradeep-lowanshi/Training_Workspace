class CompareTo{
public static void main(String[] args){
String s1 = "Yash";
String s2 = "Yash";
System.out.println(s1.compareTo(s2));
//System.out.println(s1.equalsIgnoreCase(s2));
}
}
//It returns 0  if string are equals