class EvenOddString{
public static void main(String[] args){
String s = args[0];
//String s = "Welcome";
int l = s.length();
if(l%2==0){
for(int i =0;i<l /2;i++){
System.out.print(s.charAt(i));
}
}
else{
	System.out.println("null");
}
}
}