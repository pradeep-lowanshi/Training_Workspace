class IsEmpty{
public static void main(String[] args){
String sb = "";
System.out.println(sb.isEmpty());
}
}
//It returns true or false if the string is empty or the length is 0