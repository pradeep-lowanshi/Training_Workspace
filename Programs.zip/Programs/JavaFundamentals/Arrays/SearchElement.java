class SearchElement{
public static void main(String [] args){
int[] a = {20,30,10,40,5,7};
int b = Integer.parseInt(args[0]);
int index = 0;
boolean flag = false;
for(int i =0;i<a.length;i++){
	if(a[i]==b){
		//System.out.println(i);
		index =i;
		flag = true;
		break;
	}
	else{flag=false;}
	
}
if(flag){
	System.out.println(index);
}
else{
	System.out.println("-1");
}
}
}