class LargestSmallest{

public static void main(String [] args){
int[] a = {3,5,2,8,10,6,20,12};
int temp = 0;
for(int i =0;i<a.length;i++){
 for(int j =i;j<a.length;j++){
 if(a[i]>a[j]){
 temp = a[i];
 a[i]= a[j];
 a[j]=temp;
 }
 }
}
int n = a.length;

System.out.println("Smallest 1 ="+a[0]+ " Smallest 2="+a[1] +"Largest 1 ="+a[n-2]+"Largest 2 ="+a[n-1]);

}
}