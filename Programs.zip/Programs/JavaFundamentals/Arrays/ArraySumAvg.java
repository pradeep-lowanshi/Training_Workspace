class ArraySumAvg{
public static void main(String [] args){
int[][] a = {{10,20,30},{40,50,},{60,70,80}};
int sum = 0;
int count =0;
for(int ir[]:a){
for(int i: ir){
sum = sum+i;
count++;
}

}System.out.println("sum="+sum);
int avg = sum/count;
System.out.println("average="+avg);

}}