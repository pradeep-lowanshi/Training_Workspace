class MinMaxOfArray{
  public static void main(String [] args){
    int[] a = {10,30,5,40,60,68,3};
	int min =a[0];
	int max =0;
	
	for(int i:a){
	if(i> max){
	  max = i;
	}
	if(i<min){
	min = i;
	}
	}
	System.out.println("Max = "+max +"Min = "+min);
  }
}