class AnoArray{
public static void main(String [] args){
AnoArray.sum(new int[]{10,20,30});
AnoArray.tsum(new int [][]{{10,20,30},{40,50}})
}
static void sum(int [] no){
int total = 0;
for(int i : no){
  total = total+i;
}system.out.println(total);
}
static void tsum(int [][] no){
	int t = 0;
	for(int ir[]:no){
		for(int i:ir){
			t=t+i
		}
		
	}
	

}
}