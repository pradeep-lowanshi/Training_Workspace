class BiggestElement
{
	public static void main(String[] args)
	{
		int a = args.length;
		int[][] b = new int[3][3];
	if(a<9)
	{
		System.out.println("Enter 9 value");
	}
	if(a==9)
	{
		int k =0;
		for(int i = 0;i<3;i++)
		{
			for(int j =0;j<3;j++){
			b[i][j] = Integer.parseInt(args[k]);
			k++;
				}
		}
	}
	int max = b[0][0];
	for(int i =0 ;i<b.length;i++)
	{
		for(int j =0;j<b.length;j++){
		System.out.print(b[i][j]);
		}System.out.println();
	}
	for(int i =0;i<b.length;i++)
	{
		for(int j = 0;j<b.length;j++)
		{
		
			if(b[i][j]>max)
			{
				max = b[i][j];
				
			}
	
		}
		
	}System.out.println("Max =" +max);
}
}