class SumExcludingElements{
public static void main(String[] args){
int[] a = {2,4,5,6,4,2,7,10,3};
int temp_1= 0;
int temp_2= 0;
for(int i =0;i<a.length;i++){
if(a[i]==6){
temp_1=i;}
if(a[i]==7){
temp_2 = i;
}
}
int sum = 0;
for(int i=0;i<temp_1;i++){
sum+=a[i];
}
for(int i = temp_2+1;i<a.length;i++){
sum+=a[i];

}
System.out.println(sum);
}
}