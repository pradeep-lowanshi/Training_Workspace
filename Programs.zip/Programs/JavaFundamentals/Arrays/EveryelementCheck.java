class EveryElementCheck{
public static void main(String[] args){
//int[] a = {1,4,1,4,1,4};
int[] a = {1,2,1,4,1,4};
int count =0;
for(int i : a){
if(i!=1&&i!=4){
//System.out.println("false");
count++;
}
/*else{
System.out.println("true");
}*/
}
if(count>0){
	System.out.println("false");
}
else{
	System.out.println("True");
}
}
}