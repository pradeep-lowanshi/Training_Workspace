class RemoveDuplicate{
public static void main(String [] args){
  int[] a = {10,12,2,4,10,12,15};
  
int temp = 0;
for(int i =0;i<a.length;i++){
 for(int j =i;j<a.length;j++){
 if(a[i]>a[j]){/*We will do swaping */
 temp = a[i];
 a[i]= a[j];
 a[j]=temp;
 }
 }
}//Sorting is done here

int j =0;
int n = a.length;
for(int i =0;i<n-1;i++){
	if(a[i]!= a[i+1]){
		a[j++]=a[i];
		
	}
}
a[j++]=a[n-1];
for(int i = 0;i<j;i++){
	System.out.println(a[i]);
}
}
}