class JaggedArray{
public static void main(String [] args)
{
   int[][] a = new int[3][];
   a[0]=new int[3];
   a[1] = new int[2];
   a[2] = new int[3];
   System.out.println(a);//[[I@15db97   : same
  //System.out.println(a[0]);//null :[I@15db9742
   //System.out.println(a[0][0]);// java.lang.NullPointerException :0
   //System.out.println(a.length);//2
   //System.out.println(a[0][0].length);// int cannot be dereferenced
}
}