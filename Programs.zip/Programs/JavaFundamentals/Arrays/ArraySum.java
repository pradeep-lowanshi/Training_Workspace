class ArraySum{
public static void main(String [] args){
int[] a = {10,20,30,40,50};
int sum = 0;

for(int i : a){
sum = sum+i;
}
int avg = sum/a.length;
System.out.println("sum ="+sum);
System.out.println("average = "+avg);
}
}