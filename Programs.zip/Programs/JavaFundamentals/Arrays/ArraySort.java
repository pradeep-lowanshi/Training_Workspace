class ArraySort{
public static void main(String[] args){
int[] a = {3,5,2,8,10,6,20,12};
int temp = 0;
for(int i =0;i<a.length;i++){
 for(int j =i;j<a.length;j++){
 if(a[i]>a[j]){/*We will do swaping */
 temp = a[i];
 a[i]= a[j];
 a[j]=temp;
 }
 }
}
for(int i =0;i<a.length;i++){
System.out.println(a[i]);
}
}
}