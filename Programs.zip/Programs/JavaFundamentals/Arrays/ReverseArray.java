class ReverseArray{
public static void main(String[] args){
int[][] a = {{1,2},{3,4}};
for(int i =0;i<a.length;i++){
for(int j =0;j<a.length;j++){
System.out.print(a[i][j]);
}
System.out.println();
}
for(int i =1;i>=0;i--){
for(int j =1;j>=0;j--){
System.out.print(a[i][j]+"");
}
System.out.println();
}
}
}