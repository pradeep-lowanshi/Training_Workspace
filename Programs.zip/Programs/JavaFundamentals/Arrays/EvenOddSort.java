class EvenOddSort{
public static void main(String[] args){
int[] a ={10,3,4,5,6,8};
int temp = 0;
int j =-1;
for(int i =0;i<a.length;i++){
if(a[i]%2==0){
	j++;
temp = a[i];
a[i] =a[j];
a[j] = temp;

}
}
for(int i  = 0;i<a.length;i++){
System.out.print(" "+a[i]);}
}
}