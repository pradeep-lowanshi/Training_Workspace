class MiddleArray{
public static void main(String[] args){
int[] a = {1,2,3};
int[] b = {3,4,5};
int[] c = {a[1],b[1]};
for(int i :c){
System.out.println(i);
}
}
}