class ThreadInterruptedDemo2 extends Thread
{
	public void run()
	{	
		//System.out.println(Thread.interrupted());//true-->Current status -->true-->false
		//System.out.println(Thread.interrupted());//curent status -->false
		//System.out.println(Thread.interrupted());
		System.out.println(Thread.currentThread().interrupted());//true
		System.out.println(Thread.currentThread().interrupted());//false
		for(int i =1;i<=3;i++)
				{
					try
					{
						System.out.println(i);
						Thread.sleep(2000);
						System.out.println(Thread.isInterrupted());
						System.out.println(Thread.currentThread().isInterrupted());
					}
					catch(Exception e)
					{
						
						e.printStackTrace();
					}
				}
	}
	
	public static void main(String[] args)
	{
		ThreadInterruptedDemo2 ti = new ThreadInterruptedDemo2();
		ti.start();//Thread -0
		ti.interrupt();
		
	}
}
