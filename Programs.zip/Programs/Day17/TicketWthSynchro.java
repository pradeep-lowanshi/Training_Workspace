class BookTicket
{
	 //int totalseats =12;
	 static int totalseats =12;//to achieve class synchronization when there is multiple class or threads running
	 //void bookSeats(int seats)
	//synchronized void bookSeats(int seats)
	 //void bookSeats(int seats)
	 static synchronized void bookSeats(int seats)//for multiple threads running
	 {
		//500 line
		//synchronized(object referenceName)
		//synchronized(this)//synchronized block
		{//if there are many lines of code so preventing to make whole code sychronised we use synchronized block to only make synchronized block
			 if(totalseats>=seats)
		 {
			System.out.println("Booked Successfully");
			totalseats = totalseats-seats;
			System.out.println("Remaining seats"+totalseats);
		 }
		 else
		 {
			 System.out.println("Seats are not available"+totalseats);
		 }
		 //500 line
		}
	 }//object lock
}
class Thread1 extends Thread
{
	static BookTicket b ;
	int seats;
	Thread1(BookTicket b,int seats)
	{
		
		this.b = b;
		this.seats = seats;
	}
	public void run()
	{
		
		b.bookSeats(seats);
	}
}
class Thread2 extends Thread
{
	static BookTicket b ;
	int seats;
	Thread2(BookTicket b,int seats)
	{
		
		this.b = b;
		this.seats = seats;
	}
	public void run()
	{
		
		b.bookSeats(seats);
	}
	
}
public class TicketWthSynchro extends Thread
{
	/*static BookTicket();
	int seats;
	public void run()
	{
		b = new bookSeats(seat);
	}*/
	public static void main(String[] args)
	{
		/*b = new BookTicket();
		TicketWthSynchro p1 = new TicketWthSynchro();
		p1.seats = 8;
		p2.start();
		TicketWthSynchro p2 = new TicketWthSynchro();
		p2.seats = 10;
		p2.start();*/
		
		//For multiple threads and classes
		
		BookTicket b = new BookTicket();//12
		Thread1 t1 = new Thread1(b,8);//12-8=4
		t1.start();
		Thread2 t2 = new Thread2(b,3);//4-3=1
		t2.start();
		BookTicket b1 = new BookTicket();//12
		Thread1 t3 = new Thread1(b1,3);//12-3=9
		t3.start();
		Thread2 t4 = new Thread2(b1,4);
		t4.start();
		
	}
	
}