
class Revenue extends Thread
{
	int total =0;
	public void run()
	{
		synchronized(this)
		{
		
			for(int i =1;i<=5;i++     )
			{
				total = total+400;
			}
			
		}
	}
}
class Revenue1 extends Thread
{
	int total =0;
	Revenue r;
	Revenue1(Revenue r)
	{
		this.r = r;
	}
	public void run()
	{
		synchronized(this)
		{
		
			for(int i =1;i<=5;i++     )
			{
				total = total+400;
			}
			this.notifyAll();
		}
	}
}
class NotifyAllDemo
{
	 public static void main(String[] args)throws Exception
	 {
		Revenue r = new Revenue();
		r.start();
		Revenue1 r1 = new Revenue1(r);
		
		//r1.start();
		synchronized(r)
		{
			r.wait(1000);
			
			System.out.println("Amount: "+r.total);
		}
		synchronized(r1)
		{
			r1.wait(1000);
			System.out.println("Total Amount: "+r1.total);
			
		}
	 }
}