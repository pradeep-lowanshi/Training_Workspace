interface LambdaFunctionDemo
{
	public void show();
}
class LambdaDemo
{
	public static void main(String[] args)
	{
		LambdaFunctionDemo l = ()->
		{
			System.out.println("Hello this is lambda demo");
		};
		l.show();
	}
}