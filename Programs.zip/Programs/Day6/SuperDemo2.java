class A{
void display(){
System.out.println("A class");
}
}
class SuperDemo2 extends A{
void display(){
System.out.println("SuperDemo2 ");
}
void show(){
display();
super.display();
}
public static void main(String[] args){
SuperDemo2 sd = new SuperDemo2();
sd.show();
}
}