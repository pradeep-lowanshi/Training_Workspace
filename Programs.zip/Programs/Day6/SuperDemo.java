class A{
int a =100;
}
class SuperDemo extends A{
int a = 200;//instance
void display(int a)//local
{
System.out.println(a);//300
System.out.println(this.a);
System.out.println(super.a);
}
public static void main(String[] args){
SuperDemo sd = new SuperDemo();
sd.display(300);
}
}