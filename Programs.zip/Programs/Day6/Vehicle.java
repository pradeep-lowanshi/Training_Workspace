abstract class Vehicle{
abstract void start();
/*void show(){

}*/
}
class Car extends Vehicle{
void start(){
System.out.println("It starts with key");
}
}
class Bike extends Vehicle{
void start(){
System.out.println("It starts with kick");

}
public static void main(String[] args){
//Vehicle v = new Vehicle();
Car c = new Car();
c.start();
Bike b = new Bike();
b.start();
//b.show();
}
}