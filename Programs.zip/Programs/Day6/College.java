abstract class College{
abstract void Id();
}
class Student extends College{
void Id(){
System.out.println("10001");
}
public static void main(String[] args){
Student s = new Student();
s.Id();
}
}