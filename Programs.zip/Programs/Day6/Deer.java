interface Animal{
void eat();
}
interface Behavior{
void behavior();
}
class Deer implements Animal,Behavior{
public void eat(){
System.out.println("Eats Leaves and grass");
}
public void behavior(){
System.out.println("Herbivorous");
}
public static void main(String[] args){
Deer d = new Deer();
d.eat();
d.behavior();
}
}