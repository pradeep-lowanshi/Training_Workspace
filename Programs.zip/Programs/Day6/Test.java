class Test{
void show(){

}
}
interface B implements Test{
void show();
}