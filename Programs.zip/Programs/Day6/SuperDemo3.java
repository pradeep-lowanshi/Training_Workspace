class A{
A(){
System.out.println("A Class");
}
}
class SuperDemo3 extends A{
SuperDemo3(){
super();
System.out.println("SuperDemo3 Constructor");
}
public static void main(Strong[] args){
SuperDemo3 sd = new SuperDemo3();

}
}