class Dog{
void show(){}
}
class Cat extends Dog{
void show(){}
public static void main(String[] args){
Dog d = new Dog();
Cat c = (Cat)d;

}
}