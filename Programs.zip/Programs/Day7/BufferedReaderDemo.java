import java.io.BufferedReader;
import java.io.InputStreamReader;
class BufferedReaderDemo{
public static void main(String[] args)throws Exception{
InputStreamReader inr = new InputStreamReader(System.in);
BufferedReader br = new BufferedReader(inr);
String str = br.readLine();
System.out.println(str);
}
}