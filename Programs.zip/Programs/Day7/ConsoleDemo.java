import java.io.Console;
class ConsoleDemo{
public static void main(String[] args){
String str;
char ch[];
Console ob = System.console();
System.out.println("UserName");
str = ob.readLine();
System.out.println("Password");
ch = ob.readPassword();
String a = String.valueOf(ch);
System.out.println("UserName "+str+" Password "+ch);
System.out.println("Actual Password "+a);
}
}