import javax.swing.JOptionPane;
class JOptionDemo{
public static void main(String[] ars){
//JOptionPane.showMessageDialog(null,"Hello");
//String s = JOptionPane.showInputDialog(null,"Enter");
//JOptionPane.showMessageDialog(null,s);
JOptionPane.showConfirmDialog(null,"Confirm");
}
}