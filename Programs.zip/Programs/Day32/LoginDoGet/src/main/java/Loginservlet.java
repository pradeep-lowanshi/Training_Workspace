

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Loginservlet
 */
@WebServlet("/Loginservlet")
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
	PrintWriter out = res.getWriter();
	String username = req.getParameter("x");
	String password = req.getParameter("y");
//	String email  = req.getParameter("e");
//	String phone = req.getParameter("p");
//	String city = req.getParameter("c");
	if(password.equals("yash")) 
	{
		out.println("Welcom to yash technology");
		out.println(req.getParameter("x"));
		out.println(req.getParameter("y"));
		out.println(req.getParameter("e"));
		out.println(req.getParameter("p"));
		out.println(req.getParameter("c"));
		
	}
	else 
	{
		out.println("error");
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, res);
	}

}
