import java.io.*;
import java.util.Scanner;
class Employee implements Serializable{
private String name;
private String deparment;
private String designation;
private double salary;
Employee(String name,String deparment,String designation,double salary){
this.name = name;
this.deparment = deparment;
this.designation = designation;
this. salary = salary;
}

/*public String getName(){
return name;
}
public String getDeparment(){
return deparment;
}
public String getDesignation(){
return designation;
}
public double getSalary(){
return salary;
}*/
public String toString(){
	return name+" "+deparment+" "+designation+" "+salary;
	
}
}

class EmployeeConstructor{
public static void main(String[] args)throws Exception{
Scanner sc = new Scanner(System.in);
String name = sc.nextLine();
String deparment = sc.nextLine();
String designation = sc.nextLine();
double salary = sc.nextDouble();
Employee e = new Employee(name,deparment,designation,salary);

File f = new File("D:/pradeep/yash.txt");
ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));

o.writeObject(e);

o.close();
ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
e = (Employee)ois.readObject();
ois.close();
System.out.println(e);
}
}
