enum Week{
MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;
}
class Choice{
public static void main(String[] args){
//int ch = Week.valueOf("MONDAY").ordinal();
//int ch = Integer.parseInt(args[0]);
String ch = args[0];
switch(ch){
case "MONDAY" :
System.out.println("Value of:"+Week.valueOf("MONDAY"));
	System.out.println("Index of:"+Week.valueOf("MONDAY").ordinal());

break;
case "TUESDAY" :
System.out.println("Value of:"+Week.valueOf("TUESDAY"));
	System.out.println("Index of:"+Week.valueOf("TUESDAY").ordinal());
break;
case "WEDNESDAY":
System.out.println("Value of:"+Week.valueOf("WEDNESDAY"));
	System.out.println("Index of:"+Week.valueOf("WEDNESDAY").ordinal());
break;
case "THURSDAY":
System.out.println("Value of:"+Week.valueOf("THURSDAY"));
	System.out.println("Index of:"+Week.valueOf("THURSDAY").ordinal());
break;
case "FRIDAY":
System.out.println("Value of:"+Week.valueOf("FRIDAY"));
	System.out.println("Index of:"+Week.valueOf("FRIDAY").ordinal());
break;
case "SATURDAY":
System.out.println("Value of:"+Week.valueOf("SATURDAY"));
	System.out.println("Index of:"+Week.valueOf("SATURDAY").ordinal());
break;
case "SUNDAY":
System.out.println("Value of:"+Week.valueOf("SUNDAY"));
	System.out.println("Index of:"+Week.valueOf("SUNDAY").ordinal());
break;
}
      
} 
}
