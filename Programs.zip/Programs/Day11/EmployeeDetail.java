import java.io.*;
import java.util.Scanner;
class Employee implements Serializable{
private String name;
private String deparment;
private String designation;
private double salary;
public void setName(String name){
this.name = name;
}
public void setDepartment(String deparment){
this.deparment = deparment;
}
public void setDesignation(String designation){
this.designation = designation;
}
public void setSalary(double salary){
this.salary = salary;
}

public String getName(){
return name;
}
public String getDeparment(){
return deparment;
}
public String getDesignation(){
return designation;
}
public double getSalary(){
return salary;
}
public String toString(){
	return name+" "+deparment+" "+designation+" "+salary;
	
}
}

class EmployeeDetail{
public static void main(String[] args)throws Exception{
Employee e = new Employee();

File f = new File("D:/pradeep/yash.txt");
ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
Scanner sc =new Scanner(System.in);
e.setName(sc.nextLine());
e.setDepartment(sc.nextLine());
e.setDesignation(sc.nextLine());
e.setSalary(sc.nextDouble());
o.writeObject(e);

o.close();
ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
e = (Employee)ois.readObject();
ois.close();
System.out.println(e);
}
}
