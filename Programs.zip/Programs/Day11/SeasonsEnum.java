class SeasonsEnum{
enum Seasons{
	SUMMER,WINTER,RAIN,SPRING,AUTUMN;
	
}
public static void main(String[] args){
	for(Seasons s : Seasons.values()){
		System.out.println(s);
		
	}
	System.out.println("Value of:"+Seasons.valueOf("WINTER"));
	System.out.println("Index of:"+Seasons.valueOf("WINTER").ordinal());
	
	
}
}