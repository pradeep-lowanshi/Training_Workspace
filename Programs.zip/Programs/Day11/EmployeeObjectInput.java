import java.io.*;
/*class Employee implements Serializable{
int empId;
String empName;
Employee(int empId,String empName){
this.empId = empId;
this.empName= empName;
}

public String toString(){
return empId +" "+empName;
}
}*/
class EmployeeObjectInput implements Serializable{
public static void main(String[] args)throws Exception{
//Employee e = new Employee(27,"Jaynam");
//System.out.println(e);
File f=new File("D:/pradeep/abc.txt");
ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
Employee e = (Employee)ois.readObject();
ois.close();
System.out.println(e);
/*ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
oos.writeObject(e);
oos.close();*/

}
}