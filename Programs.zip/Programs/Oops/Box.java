class Box{
int width;
int height;
int depth;
Box(int width,int height,int depth){
this.width = width;
this.height = height;
this.depth = depth;
}
void volume(){
int volume = height*width*depth;
System.out.println(volume);
}
public static void main(String[] args){
Box b = new Box(10,10,10);
b.volume();
}
}