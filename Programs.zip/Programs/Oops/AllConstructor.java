class AllConstructor{

String name ;
int age ;
public AllConstructor(){
System.out.println("No Argument constructor");
}
public AllConstructor(String name, int age){
this.name = name;
this.age = age;
}
public static void main(String [] args){
AllConstructor na = new AllConstructor();
AllConstructor ac = new AllConstructor("yash",20);
System.out.println(ac.name+" "+ac.age);

}
}