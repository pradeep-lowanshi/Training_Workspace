class InstanceVariable{
String str;
void enter(String str){
this.str = str;
}
void show(){
System.out.println(str);
}
}
class InstanceVariableDemo{
public static void main(String[] args){
InstanceVariable iv = new InstanceVariable();
iv.enter("Hey");
iv.show();
}
}