class Fruit{
String name,taste,size;
void eat(String name,String taste, String size){
System.out.println(name+" "+taste+" "+size);
}
}
class Apple extends Fruit{
void eat(String name, String taste, String size){
System.out.println(name+" "+taste+" "+size);
}
}
class Orange extends Fruit{
void eat(String name, String taste, String size){
System.out.println(name+" "+taste+" "+size);
}
public static void main(String[] args){
Apple a = new Apple();
Orange o = new Orange();
a.eat("Apple","Sweet","Medium Round");
o.eat("Orange","Sour","Medium Round");

}
}