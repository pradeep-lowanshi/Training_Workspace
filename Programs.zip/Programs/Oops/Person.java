class Person{
String name;
String dateOfBirth;
Person(String name,String dateOfBirth){
this.name = name;
this.dateOfBirth = dateOfBirth;
}
}
class Teacher extends Person{
double salary;
String subject;
//Person p ;
Teacher(String name, String dateOfBirth, double salary,String subject){
super(name,dateOfBirth);
this.subject = subject;
this.salary = salary;
}
void display(){
System.out.println(name+""+dateOfBirth+""+salary+""+subject);
}

}
class Student extends Person{
int studentId;
Student(String name,String dateOfBirth, int studentId){
super(name,dateOfBirth);
this.studentId = studentId;
}

}
class CollegeStudent extends Student{
String collegeName;
String year;
CollegeStudent(String name, String dateOfBirth,int studentId, String year,String collegeName){
super(name,dateOfBirth,studentId);
this.year = year;
this.collegeName = collegeName;
}
void display(){
	System.out.println(name+" "+dateOfBirth+" "+studentId+" "+year+" "+collegeName);
	
}
}
 class Details {
public static void main(String[] args){
Teacher t = new Teacher("Ram","20/02/1998",50000,"Java");
CollegeStudent cs = new CollegeStudent("Raj","30/06/2000",001,"Fourth","Medicaps");
t.display();
cs.display();
}
}