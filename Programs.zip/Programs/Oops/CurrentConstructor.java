class CurrenConstructor{
CurrenConstructor(){
System.out.println("We are dong Java FullStack Training");
}
CurrenConstructor(int a){
this();
System.out.println(a);
}
public static void main(String[] args){
CurrenConstructor c = new CurrenConstructor(10);

}
}