class OverRiding{
void show(){
System.out.println("first method");
}
}
class OverB extends OverRiding{
void show(){
System.out.println("Over ridden method");
}
public static void main(String[] args){
OverB ob = new OverB();
ob.show();
}
}