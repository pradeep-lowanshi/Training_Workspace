class OverRiding2{
void show(int a){
System.out.println("first method");
}
}
class OverB2 extends OverRiding{
int show(int a){
System.out.println("Over ridden method");
return a;
}
public static void main(String[] args){
OverB2 ob = new OverB2();
System.out.println(ob.show(10));
}
}