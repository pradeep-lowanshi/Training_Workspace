class MethodCall{
void show(){
System.out.println("Welcome to yash");
}
void display(){
this.show();
}
public static void main(String [] args){
MethodCall m = new MethodCall();
m.display();
}
}