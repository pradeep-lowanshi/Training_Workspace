class t1 {
	t1(ThisDemo5 td ){
		System.out.println("t1 class Constructor");
		
	}
	
}
class  ThisDemo5{
	void y1(){
		t1 t = new t1(this);
	}
	public static void main(String[] args){
		ThisDemo5 t1 = new ThisDemo5();
		t1.y1();
		
	}
}