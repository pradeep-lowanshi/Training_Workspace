class Patient{
String patientName;
double height;
double weight;
Patient(String patientName, double height, double weight){
this.patientName = patientName;
this. height =height;
this. weight = weight;
}
double computeBMI(){
double BMI = weight/(height*height);
//System.out.println(BMI);
return BMI;
}
public static void main(String[] args){
Patient p = new Patient("Raj",1.5,56.5);
System.out.println(p.computeBMI());
}
}