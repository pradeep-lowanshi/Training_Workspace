class Author{
private String name;
private String email;
private char gender;
Author(String name, String email, char gender){
this.name = name;
this.email = email;
this.gender = gender;
}

public String getName(){
	return name;
}
public String getEmail(){
	return email;
}
public char getGender(){
	return gender;
}
public String toString(){
	return name+ " "+email+" "+gender;
	
}
}
class Book{
private String name;
Author a;
private double price;
private int qtyInStock;
Book(String name,Author a,double price,int qtyInStock){
this.name = name;
this.a = a;
this. price = price;
this.qtyInStock = qtyInStock;

}
public String getBName(){
	return name;
}
public double getPrice(){
	return price;
}
public int getQty(){
	return qtyInStock;
}
public Author getAuthor(){
	return a;
}
public String toString(){
	return name+" "+price+" "+qtyInStock+" "+a;
}
}

class BookDetail{
public static void main(String[] args){
Author a= new Author("Robin Sharma","rs@gmail.com",'m');
Book b= new Book("Who will cry when you die",a,200,40);
System.out.println(b);
}
}