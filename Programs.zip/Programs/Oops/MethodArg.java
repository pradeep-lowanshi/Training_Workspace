class MethodArg{
void method1(MethodArg m){
System.out.println("Hey java is purely oops");
} 
void method2(){
method1(this);
}
public static void main(String[] args){
MethodArg m = new MethodArg();
m.method2();

}
}