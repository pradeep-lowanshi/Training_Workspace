class ThisDemo3{
ThisDemo3(){
System.out.println("No Argument");
//this(10);
}
ThisDemo3(int a){
this();
System.out.println("Parameterised");
}
public static void main(String[] args){
ThisDemo3 t = new ThisDemo3(10);
}
}