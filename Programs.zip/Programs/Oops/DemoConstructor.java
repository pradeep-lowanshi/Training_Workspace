class DemoConstructor{
DemoConstructor(){
System.out.println("Default Constructor");
}
public static void main(String[] args){
DemoConstructor t = new DemoConstructor();
}
}