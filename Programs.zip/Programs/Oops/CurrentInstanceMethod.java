class CurrentInstanceMethod{
int a = 10;
void show(){
return this.a;
}
public static void main(String[] args){
CurrentInstanceMethod c = new CurrentInstanceMethod();
c.show();
}
}