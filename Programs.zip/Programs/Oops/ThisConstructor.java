class ConstructorArgu{
	ConstructorArgu(ThisConstructor c){
		System.out.println("ConstructorArg is called");
		
	}
}
class ThisConstructor{
	void display(){
		ConstructorArgu c = new ConstructorArgu(this);
		
	}
	public static void main(String[] args){
	ThisConstructor t = new ThisConstructor();
	t.display();
		
	}
}
