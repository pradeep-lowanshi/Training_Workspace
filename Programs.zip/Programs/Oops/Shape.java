class Shape{
void draw(){}
void erase(){}
}
class Circle extends Shape{
void draw(){
System.out.println("Drawing Circle");
System.out.println("Erasing Circle");
}
}
class Triangle extends Shape{
void draw(){
System.out.println("Drawing Triangle");
System.out.println("Erasing Triangle");
}
}
class Square extends Shape{
void draw(){
System.out.println("Drawing Square");
System.out.println("Erasing Square");
}
public static void main(String[] args){
Circle c = new Circle();
Triangle t = new Triangle();
Square s = new Square();
c.draw();
c.erase();
t.draw();
t.erase();
s.draw();
s.draw();
}
}