class OverRiding3{
private void show(Object a){
System.out.println("first method");
}
}
class OverB3 extends OverRiding{
public void show(String a){
System.out.println("Over ridden method");
//return a;
}
public static void main(String[] args){
OverB3 ob = new OverB3();
//System.out.println(ob.show(10));
ob.show("Jay");
}
}