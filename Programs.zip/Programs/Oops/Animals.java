class Animal{
void eat(){System.out.println("I am eating");}
void sleep(){System.out.println("I am sleeping");}
}
class Bird extends Animal{
void eat(){
System.out.println("Birds eat leaves");
}
void sleep(){
System.out.println("Birds sleep on trees");
}
void fly(){
System.out.println("Birds fly high");
}
public static void main(String[] args){
Animal a = new Animal();
a.eat();
a.sleep();
Bird b = new Bird();
b.eat();
b.sleep();
b.fly();
}
}